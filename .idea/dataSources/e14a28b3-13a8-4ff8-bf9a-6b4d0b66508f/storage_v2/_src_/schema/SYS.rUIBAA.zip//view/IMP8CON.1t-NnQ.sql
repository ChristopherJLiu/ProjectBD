CREATE VIEW IMP8CON AS
  SELECT  c.name, o.name, u.name, cc.intcol#
        FROM    sys.obj$ o, sys.user$ u, sys.con$ c, sys.ccol$ cc,
                sys.cdef$ cd
        WHERE   o.obj# = cc.obj# AND
                c.con# = cc.con# AND
                o.obj# = cd.obj# AND
                u.user# = c.owner# AND
                cd.con# = c.con# AND
                cd.type# = 3 AND
                BITAND(cd.defer, 8) = 8
/

