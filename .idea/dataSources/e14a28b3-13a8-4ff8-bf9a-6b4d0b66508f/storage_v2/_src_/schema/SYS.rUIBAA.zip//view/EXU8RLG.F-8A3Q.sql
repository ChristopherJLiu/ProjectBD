CREATE VIEW EXU8RLG AS
  SELECT  u1$.name, u1$.user#, u2$.name, u2$.user#, NVL(g$.option$, 0),
                g$.sequence#
        FROM    sys.user$ u1$, sys.user$ u2$, sys.sysauth$ g$
        WHERE   u1$.user# = g$.grantee# AND
                u2$.user# = g$.privilege# AND
                g$.privilege# > 0 AND
                u1$.name NOT IN ('ORDSYS',  'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                                'LBACSYS', 'XDB',   'SI_INFORMTN_SCHEMA',
                                'DIP',  'DBSNMP', 'EXFSYS', 'WMSYS',
                                'ORACLE_OCM', 'ANONYMOUS', 'XS$NULL',
                                'APPQOSSYS')
/

