CREATE VIEW ALL_CHANGE_SETS AS
  SELECT
   s.set_name, s.change_source_name, s.begin_date, s.end_date, s.begin_scn,
   s.end_scn, s.freshness_date, s.freshness_scn,
   (case when (s.change_source_name = 'SYNC_SOURCE') then s.advance_enabled
         when (a.status = 2 and c.status = 2) then 'Y'
         when a.status = 2 then 'C'
         else 'N' end) advance_enabled,
   s.ignore_ddl, s.created, s.rollback_segment_name, s.advancing, s.purging,
   s.lowest_scn, s.tablespace,
   (case when (s.change_source_name = 'SYNC_SOURCE') then s.capture_enabled
         else decode(a.status, 2, 'Y', 'N') end) capture_enabled,
   s.stop_on_ddl,
   (case when (s.change_source_name = 'SYNC_SOURCE') then s.capture_error
         when (a.status = 1 and e.error_number is not null) then 'Y'
         when (a.apply_name is null) then 'Y'
         else 'N' end) capture_error,
   s.capture_name, s.queue_name, s.queue_table_name,
   s.apply_name, s.set_description, s.publisher, s.lowest_timestamp,
   s.time_scn_name
  FROM sys.cdc_change_sets$ s,
       sys.streams$_apply_process a, sys.streams$_capture_process c,
       sys.apply$_error e
  WHERE s.apply_name = a.apply_name (+)
  AND a.apply# = e.apply# (+)
  AND s.capture_name = c.capture_name (+)
/

