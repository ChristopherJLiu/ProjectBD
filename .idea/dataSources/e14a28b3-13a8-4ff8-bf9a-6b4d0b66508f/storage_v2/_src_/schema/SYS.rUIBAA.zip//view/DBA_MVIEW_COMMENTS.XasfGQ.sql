CREATE VIEW DBA_MVIEW_COMMENTS AS
  select u.name, o.name, c.comment$
from sys.obj$ o, sys.user$ u, sys.com$ c, sys.tab$ t
  where o.owner# = u.user# AND o.type# = 2
  and (bitand(t.property, 67108864) = 67108864)         /*mv container table */
  and o.obj# = c.obj#(+)
  and c.col#(+) is NULL
  and o.obj# = t.obj#
/

