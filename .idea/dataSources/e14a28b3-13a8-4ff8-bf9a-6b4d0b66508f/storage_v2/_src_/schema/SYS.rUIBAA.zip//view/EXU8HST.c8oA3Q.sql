CREATE VIEW EXU8HST AS
  SELECT  h$.obj#, o$.owner#, h$.intcol#, h$.bucket, h$.endpoint,
                h$.epvalue
        FROM    sys.histgrm$ h$, sys.obj$ o$
        WHERE   h$.obj# = o$.obj#
      UNION ALL
        SELECT  h$.obj#, o$.owner#, h$.intcol#, 0, h$.minimum, NULL
        FROM    sys.hist_head$ h$, sys.obj$ o$
        WHERE   h$.obj# = o$.obj# AND
                h$.bucket_cnt = 1
      UNION ALL
        SELECT  h$.obj#, o$.owner#, h$.intcol#, 1, h$.maximum, NULL
        FROM    sys.hist_head$ h$, sys.obj$ o$
        WHERE   h$.obj# = o$.obj# AND
                h$.bucket_cnt = 1
/

