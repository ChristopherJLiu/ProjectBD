CREATE VIEW IMP10TYPUSED AS
  SELECT u.name, o_tab.name, o_typ.oid$
        FROM   sys.obj$ o_tab, sys.user$ u, sys.obj$ o_typ, sys.dependency$ d
        WHERE d.p_obj# = o_typ.obj#
        AND d.d_obj# = o_tab.obj#
        AND o_tab.type# = 2
        AND o_tab.owner# = u.user#
/

