CREATE VIEW ALL_CHANGE_PROPAGATIONS AS
  SELECT
   p.sourceid_name, p.propagation_name, p.staging_database,
   p.destqueue_publisher, p.destqueue_name
  FROM sys.cdc_propagations$ p
/

