CREATE VIEW EXU81TNTC AS
  SELECT  objid, ownerid, name
        FROM    sys.exu81tabc                       /* tables in this export */
        WHERE   BITAND(property, 4) = 4           /* table has nested tables */

