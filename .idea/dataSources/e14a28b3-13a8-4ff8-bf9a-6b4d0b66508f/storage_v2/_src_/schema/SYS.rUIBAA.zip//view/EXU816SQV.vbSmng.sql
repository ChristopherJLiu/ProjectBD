CREATE VIEW EXU816SQV AS
  SELECT  sv."VERSION#",sv."SQL_VERSION"
        FROM    sys.sql_version$ sv
        WHERE   sv.version# < (
                    SELECT  m.version#
                    FROM    sys.exu816maxsqv m)
/

