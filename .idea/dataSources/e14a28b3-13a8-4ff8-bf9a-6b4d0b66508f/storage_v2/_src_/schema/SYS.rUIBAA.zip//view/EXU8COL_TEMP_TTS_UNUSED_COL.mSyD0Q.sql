CREATE VIEW EXU8COL_TEMP_TTS_UNUSED_COL AS
  SELECT  o$.obj#, u$.name, o$.owner#, o$.name, c$.name, c$.length,
                c$.precision#, c$.scale, c$.type#, NVL(cn.isnull, 0),
                cn.conname, c$.col#, c$.intcol#, c$.segcol#, c$.property,
                com$.comment$, NVL(c$.deflength, 0), cn.enabled, cn.defer,
                NVL(o$.flags, 0), NVL(c$.charsetid, 0), NVL(c$.charsetform, 0),
                c$.scale, c$.precision#, c$.spare3
        FROM    sys.col$ c$, sys.obj$ o$, sys.user$ u$, sys.com$ com$,
                sys.exu8colnn cn
        WHERE   c$.obj# = o$.obj# AND
                o$.owner# = u$.user# AND
                c$.obj# = com$.obj#(+) AND
                c$.segcol# = com$.col#(+) AND
                c$.obj# = cn.tobjid AND
                c$.intcol# = cn.intcolid
      UNION ALL
        SELECT  o$.obj#, u$.name, o$.owner#, o$.name, c$.name, c$.length,
                c$.precision#, c$.scale, c$.type#, 0, NULL, c$.col#,
                c$.intcol#, c$.segcol#, c$.property, com$.comment$,
                NVL(c$.deflength, 0), 0, 0, NVL(o$.flags, 0),
                NVL(c$.charsetid, 0), NVL(c$.charsetform, 0), c$.scale,
                c$.precision#, c$.spare3
        FROM    sys.col$ c$, sys.obj$ o$, sys.user$ u$, sys.com$ com$
        WHERE   c$.obj# = o$.obj# AND
                o$.owner# = u$.user# AND
                c$.obj# = com$.obj#(+) AND
                c$.segcol# = com$.col#(+) AND
                NOT EXISTS (
                    SELECT  NULL
                    FROM    sys.exu8colnn cn
                    WHERE   c$.obj# = cn.tobjid AND
                            c$.intcol# = cn.intcolid)
/

