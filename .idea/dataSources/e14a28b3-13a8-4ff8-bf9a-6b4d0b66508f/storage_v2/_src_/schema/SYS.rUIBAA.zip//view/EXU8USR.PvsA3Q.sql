CREATE VIEW EXU8USR AS
  SELECT  u.name, u.user#, DECODE(u.password, 'N', '', u.password),
                DECODE(u.defrole, 0, 'N', 1, 'A', 2, 'L', 3, 'E', 'X'),
                ts1.name, DECODE(BITAND(ts2.flags,2048),2048,'SYSTEM',ts2.name),
                u.resource$, p.name, u.astatus,
                u.ext_username
        FROM    sys.user$ u, sys.ts$ ts1, sys.ts$ ts2, sys.profname$ p
        WHERE   u.datats# = ts1.ts# AND
                u.tempts# = ts2.ts# AND
                u.type# = 1 AND
                u.resource$ = p.profile# AND
                u.name NOT IN ( 'ORDSYS',  'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                                'LBACSYS', 'XDB',   'SI_INFORMTN_SCHEMA',
                                'DIP',  'DBSNMP', 'EXFSYS', 'WMSYS',
                                'ORACLE_OCM', 'ANONYMOUS', 'XS$NULL',
                                'APPQOSSYS')
/

