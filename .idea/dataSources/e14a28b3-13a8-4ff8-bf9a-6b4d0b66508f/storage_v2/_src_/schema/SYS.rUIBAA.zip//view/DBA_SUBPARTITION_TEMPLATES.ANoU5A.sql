CREATE VIEW DBA_SUBPARTITION_TEMPLATES AS
  select u.name, o.name, st.spart_name, st.spart_position + 1, ts.name,
       st.hiboundval
from sys.obj$ o, sys.defsubpart$ st, sys.ts$ ts, sys.user$ u
where st.bo# = o.obj# and st.ts# = ts.ts#(+) and o.owner# = u.user#
  and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
  and o.subname IS NULL
/

