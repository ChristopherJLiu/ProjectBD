CREATE VIEW EXU81APPROLE AS
  SELECT  u$.name, r$.schema, r$.package
        FROM    sys.user$ u$, sys.approle$ r$
        WHERE   u$.user# = r$.role#
/

