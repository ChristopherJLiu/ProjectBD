CREATE VIEW EXU8DFR AS
  SELECT  u$.name, u$.user#, u1$.name, u1$.user#
        FROM    sys.user$ u$, sys.user$ u1$, sys.defrole$ d$
        WHERE   u$.user# = d$.user# AND
                u1$.user# = d$.role#
/

