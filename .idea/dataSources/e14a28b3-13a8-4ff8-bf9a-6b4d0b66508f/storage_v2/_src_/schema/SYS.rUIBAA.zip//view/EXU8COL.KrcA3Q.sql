CREATE VIEW EXU8COL AS
  SELECT  tobjid, towner, townerid, v$.tname, v$.name, v$.length,
                v$.precision, v$.scale, type, isnull, conname, colid, intcolid,
                segcolid, comment$, default$, dfltlen, enabled, defer,
                v$.flags, colprop, '', '', v$.charsetid, v$.charsetform,
                v$.fsprecision, v$.lfprecision, v$.charlen,  NVL(ct$.flags, 0)
        FROM    sys.exu8col_temp v$, sys.col$ c$, sys.coltype$ ct$
        WHERE   c$.obj# = v$.tobjid AND
                c$.intcol# = v$.intcolid AND
                v$.tobjid = ct$.obj# (+) AND
                (BITAND(v$.colprop, 32) != 32 OR      /* not a hidden column */
                 BITAND(v$.colprop, 1048608)= 1048608 OR/*snapshot hidden col*/
                 BITAND(v$.colprop, 4194304) = 4194304) /* RLS hidden column */

