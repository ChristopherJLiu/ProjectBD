CREATE VIEW EXU10ASC AS
  SELECT  c$.obj#, hh$.obj#, o$.owner#, REPLACE(c$.name, '''', ''''''),
                hh$.intcol#,
                hh$.distcnt, hh$.lowval, hh$.hival, hh$.density, hh$.null_cnt,
                hh$.avgcln, hh$.spare2, c$.property
        FROM    sys.hist_head$ hh$, sys.obj$ o$, sys.obj$ ot$, sys.col$ c$
        WHERE   hh$.obj# = o$.obj# AND
                c$.obj# = ot$.obj# AND
                o$.owner# = ot$.owner# AND
                hh$.intcol# = c$.intcol#
/

