CREATE VIEW DBA_MVIEW_DETAIL_RELATIONS AS
  select u.name, o.name, du.name,  do.name,
       decode (sd.detailobjtype, 1, 'TABLE', 2, 'VIEW',
                                3, 'SNAPSHOT', 4, 'CONTAINER', 'UNDEFINED'),
       sd.detailalias,
           /* whether this is a PCT refresh enabled primary CUBE MV */
       (decode(bitand(s.xpflags, 8589934592), 0,
                (decode(sd.detaileut, 0, 'N', 'Y')),
               /* If there's a qualifying secondary cube mv row for this detailtab,
                  it's pct refreshable, otherwise, no. */
                (decode((select count(*)
                          from  sumdetail$ sd2
                          where sd.sumobj#=sd2.sumobj# and sd.detailobj#=sd2.detailobj#
                            and sd2.detaileut > 268435456),
                        0, 'N', 'Y')))
       ) as DETAILOBJ_PCT,
     (select num_fresh_partns from
       (select sumobj#, detailobj#,
               sum(num_fresh_partitions) as num_fresh_partns,
               sum(num_stale_partitions) as num_stale_partns
       from
        (select sumobj#, detailobj#,
                decode(partn_state, 'FRESH', partn_count, 0)
                as num_fresh_partitions,
                decode(partn_state, 'STALE', partn_count, 0)
                as num_stale_partitions
         from
          (select sumobj#, detailobj#, partn_state, count(*) as partn_count from
            (select sumobj#, detailobj#,
                    (case when partn_scn is NULL then 'FRESH'
                     when partn_scn < mv_scn
                     then 'FRESH' else 'STALE' end) partn_state
             from
              (select s.obj# as sumobj#, sd.detailobj#,
                      s.lastrefreshscn as mv_scn,
                      t.obj# pobj#, t.obj# as sub_pobj#, t.spare1 as partn_scn
               from sys.sum$ s, sys.sumdetail$ sd, sys.tabpart$ t
               where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
               union
               select s.sumobj#, s.detailobj#, s.mv_scn,
                      s.pobj# pobj#, t.obj# as sub_pobj#,t.spare1 as partn_scn
               from  tabsubpart$ t,
               (select s.obj# as sumobj#, sd.detailobj# as detailobj#,
                       s.lastrefreshscn as mv_scn,
                       t.obj# pobj#, t.spare1 as partn_scn
                from sys.sum$ s, sys.sumdetail$ sd, sys.tabcompart$ t,
                     sys.obj$ o
                where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#) s
             where t.pobj# = s.pobj#))
           group by sumobj#,detailobj#,partn_state))
         group by sumobj#,detailobj#) nfsp
         where nfsp.sumobj# = s.obj# and nfsp.detailobj# = sd.detailobj#)
         as NUM_FRESH_PCT_PARTNS,
     (select num_stale_partns from
       (select sumobj#, detailobj#,
               sum(num_fresh_partitions) as num_fresh_partns,
               sum(num_stale_partitions) as num_stale_partns
       from
        (select sumobj#, detailobj#,
                decode(partn_state, 'FRESH', partn_count, 0)
                as num_fresh_partitions,
                decode(partn_state, 'STALE', partn_count, 0)
                as num_stale_partitions
         from
          (select sumobj#, detailobj#, partn_state, count(*) as partn_count from
            (select sumobj#, detailobj#,
                    (case when partn_scn is NULL then 'FRESH'
                     when partn_scn < mv_scn
                     then 'FRESH' else 'STALE' end) partn_state
             from
              (select s.obj# as sumobj#, sd.detailobj#,
                      s.lastrefreshscn as mv_scn,
                      t.obj# pobj#, t.obj# as sub_pobj#, t.spare1 as partn_scn
               from sys.sum$ s, sys.sumdetail$ sd, sys.tabpart$ t
               where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
               union
               select s.sumobj#, s.detailobj#, s.mv_scn,
                      s.pobj# pobj#, t.obj# as sub_pobj#,t.spare1 as partn_scn
               from  tabsubpart$ t,
               (select s.obj# as sumobj#, sd.detailobj# as detailobj#,
                       s.lastrefreshscn as mv_scn,
                       t.obj# pobj#, t.spare1 as partn_scn
                from sys.sum$ s, sys.sumdetail$ sd, sys.tabcompart$ t,
                     sys.obj$ o
                where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#) s
             where t.pobj# = s.pobj#))
           group by sumobj#,detailobj#,partn_state))
         group by sumobj#,detailobj#) nfsp
         where nfsp.sumobj# = s.obj# and nfsp.detailobj# = sd.detailobj#)
         as NUM_STALE_PCT_PARTNS
from sys.user$ u, sys.sumdetail$ sd, sys.obj$ o, sys.obj$ do,
     sys.user$ du, sys.sum$ s
where o.owner# = u.user#
  and o.obj# = sd.sumobj#
  and do.obj# = sd.detailobj#
  and do.owner# = du.user#
  and s.obj# = sd.sumobj#
  and bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
  and bitand(sd.detaileut, 2147483648) = 0  /* NO secondary CUBE MV rows */

