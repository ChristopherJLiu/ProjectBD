CREATE VIEW INDCOMPARTV$ AS
  select obj#, dataobj#, bo#,
          row_number() over (partition by bo# order by part#),
          hiboundlen, hiboundval, subpartcnt, flags, defts#,
          defpctfree, definitrans, defmaxtrans, definiexts, defextsize,
          defminexts, defmaxexts, defmaxsize,
          defextpct, deflists, defgroups, deflogging,
          defbufpool, analyzetime, samplesize, rowcnt, blevel, leafcnt,
          distkey, lblkkey, dblkkey, clufac, spare1, spare2, spare3, part#
from indcompart$
/

