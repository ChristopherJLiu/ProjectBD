CREATE VIEW EXU81TNTI AS
  SELECT  objid, ownerid, name
        FROM    sys.exu81tabi                       /* tables in this export */
        WHERE   BITAND(property, 4) = 4           /* table has nested tables */

