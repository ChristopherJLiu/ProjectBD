CREATE VIEW EXU8CSET AS
  SELECT  name, DECODE (value$,'AL16UTF16','UTF8', value$)
        FROM    sys.props$
        WHERE   name IN ('NLS_CHARACTERSET',
                         'NLS_NCHAR_CHARACTERSET')
/

