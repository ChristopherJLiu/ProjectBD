CREATE VIEW EXU9IXCP AS
  SELECT  o.obj#, o.dataobj#, icp.bo#, o.owner#, o.subname, icp.part#,
                icp.hiboundlen, icp.hiboundval, NVL(icp.rowcnt, -1), -1, -1,
                ts.name, MOD(icp.defpctfree, 100), 0, icp.definitrans,
                icp.defmaxtrans, NVL(icp.definiexts, 0),
                NVL(icp.defextsize, 0), NVL(icp.defminexts, 0),
                NVL(icp.defmaxexts, 0), NVL(icp.defextpct, -1),
                NVL(icp.deflists, 0), NVL(icp.defgroups, 0),
                DECODE(bitand(icp.defbufpool,3), 1, 'KEEP', 2, 'RECYCLE', NULL),
                icp.deflogging, ts.dflogging, NVL(icp.blevel, -1),
                NVL(icp.leafcnt, -1), NVL(icp.distkey, -1),
                NVL(icp.lblkkey, -1), NVL(icp.dblkkey, -1),
                NVL(icp.clufac, -1),
                NVL(ts.blocksize, (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = (NVL((
                                SELECT  i$.ts#
                                FROM    sys.ind$ i$
                                WHERE   i$.obj# = icp.bo# AND
                                        i$.type# != 8 AND
                                        i$.type# != 4 AND
                                        BITAND(i$.flags, 4096) = 0),
                                           0)))),
                0, NVL(icp.defmaxsize, 0), icp.flags
        FROM    sys.obj$ o, sys.indcompart$ icp, sys.ts$ ts
        WHERE   icp.obj# = o.obj# AND
                icp.defts# = ts.ts# (+)
/

