CREATE VIEW EXU8COE AS
  SELECT  tobjid, towner, townerid, v$.tname, v$.name, v$.length,
                v$.precision, v$.scale, v$.type, v$.isnull, v$.conname,
                v$.colid, v$.intcolid, v$.segcolid, v$.comment$, default$,
                v$.dfltlen, v$.enabled, v$.defer, v$.flags, v$.colprop,
                o$.name, u$.name,
                DECODE (v$.name, 'SYS_NC_OID$', 1, 'NESTED_TABLE_ID', 2,
                        'SYS_NC_ROWINFO$', 3, 100),
                v$.charsetid, v$.charsetform, v$.fsprecision, v$.lfprecision,
                v$.charlen, NVL(ct$.flags, 0)
        FROM    sys.exu8col_temp v$, sys.col$ c$, sys.coltype$ ct$,
                sys.obj$ o$, sys.user$ u$
        WHERE   c$.obj# = v$.tobjid AND
                c$.intcol# = v$.intcolid AND
                (BITAND(v$.colprop, 2) = 2 OR                 /* SYS_NC_OID$ */
                 BITAND(v$.colprop, 16) = 16 OR           /* NESTED_TABLE_ID */
                 BITAND(v$.colprop, 512) = 512) AND       /* SYS_NC_ROWINFO$ */
                c$.obj# = ct$.obj# (+) AND
                c$.intcol# = ct$.intcol# (+) AND
                NVL(ct$.toid, HEXTORAW('00')) = o$.oid$ (+) AND
                NVL(o$.owner#, -1) = u$.user# (+) AND
                NVL(o$.type#, -1) != 10 /* bug 882543: no non-existent types */

