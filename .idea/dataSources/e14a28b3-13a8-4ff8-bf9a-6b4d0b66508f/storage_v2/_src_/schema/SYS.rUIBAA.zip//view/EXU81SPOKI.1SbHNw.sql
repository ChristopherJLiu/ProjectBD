CREATE VIEW EXU81SPOKI AS
  SELECT  o.obj#, o.owner#, sp.pos#, c.name, c.property, c.default$,
                c.deflength
        FROM    sys.obj$ o, sys.subpartcol$ sp, sys.ind$ i, sys.col$ c
        WHERE   o.obj# = sp.obj# AND
                i.obj# = o.obj# AND
                i.bo# = c.obj# AND
                sp.intcol# = c.intcol#
/

