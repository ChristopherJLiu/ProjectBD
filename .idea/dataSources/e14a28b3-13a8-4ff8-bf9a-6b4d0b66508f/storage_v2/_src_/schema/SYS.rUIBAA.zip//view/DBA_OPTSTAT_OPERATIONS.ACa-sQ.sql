CREATE VIEW DBA_OPTSTAT_OPERATIONS AS
  select operation, target, start_time, end_time
  from sys.wri$_optstat_opr
/

