CREATE VIEW EXU8INK AS
  SELECT  o$.obj#, o$.owner#, c$.intcol#, c$.name
        FROM    sys.obj$ o$, sys.ind$ i$, sys.col$ c$
        WHERE   i$.bo# = o$.obj# AND
                c$.obj# = o$.obj# AND
                c$.col# = i$.trunccnt AND
                i$.trunccnt != 0
/

