CREATE VIEW EXU8SPV AS
  SELECT  u1$.name, u1$.user#, m$.name, NVL(a$.option$, 0), a$.sequence#
        FROM    sys.sysauth$ a$, sys.system_privilege_map m$, sys.user$ u1$
        WHERE   a$.grantee# = u1$.user# AND
                a$.privilege# = m$.privilege AND
                BITAND(m$.property, 1) != 1 AND
                u1$.name NOT IN ('CONNECT', 'RESOURCE', 'DBA', '_NEXT_USER',
                                 'EXP_FULL_DATABASE', 'IMP_FULL_DATABASE',
                                 'ORDSYS', 'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                                 'LBACSYS', 'XDB', 'SI_INFORMTN_SCHEMA',
                                 'DIP', 'DBSNMP', 'EXFSYS', 'WMSYS',
                                 'ORACLE_OCM', 'ANONYMOUS', 'XS$NULL',
                                 'APPQOSSYS')
/

