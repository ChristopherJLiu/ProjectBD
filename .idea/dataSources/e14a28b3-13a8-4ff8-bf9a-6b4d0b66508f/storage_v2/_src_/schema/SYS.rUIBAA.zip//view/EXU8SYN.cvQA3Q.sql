CREATE VIEW EXU8SYN AS
  SELECT  o$.name, o$.name, s$.name, s$.owner, s$.node,
                DECODE(o$.owner#, 1, 1, 0), uo$.name, o$.owner#, o$.ctime
        FROM    sys.exu81obj o$, sys.syn$ s$, sys.user$ us$, sys.user$ uo$
        WHERE   s$.obj# = o$.obj# AND
                o$.owner# = uo$.user# AND
                s$.owner = us$.name(+) AND
                NVL(s$.owner, 'SYS') NOT IN
                   ('ORDSYS', 'MDSYS', 'CTXSYS', 'ORDPLUGINS', 'LBACSYS',
                    'XDB', 'SI_INFORMTN_SCHEMA', 'DIP', 'DBSNMP', 'EXFSYS',
                    'WMSYS','ORACLE_OCM', 'ANONYMOUS', 'XS$NULL',
                    'APPQOSSYS')
/

