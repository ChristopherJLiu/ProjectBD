CREATE VIEW DBA_EXTERNAL_LOCATIONS AS
  select u.name, o.name, xl.name, 'SYS', nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.user$ u, sys.obj$ o, sys.external_tab$ xt
where o.owner# = u.user#
  and o.obj# = xl.obj#
  and o.obj# = xt.obj#
/

