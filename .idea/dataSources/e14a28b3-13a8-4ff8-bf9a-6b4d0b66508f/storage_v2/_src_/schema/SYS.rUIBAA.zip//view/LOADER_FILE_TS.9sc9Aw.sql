CREATE VIEW LOADER_FILE_TS AS
  select file$.ts#, v$dbfile.name, file$.relfile#
   from file$, v$dbfile
   where file$.file# = v$dbfile.file#
/

