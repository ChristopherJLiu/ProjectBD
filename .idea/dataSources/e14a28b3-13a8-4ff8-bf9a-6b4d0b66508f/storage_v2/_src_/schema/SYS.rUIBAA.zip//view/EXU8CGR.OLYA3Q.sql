CREATE VIEW EXU8CGR AS
  SELECT  c$.obj#, ur$.name, c$.grantor#, ue$.name, o$.owner#, cl$.name,
                m$.name, c$.sequence#, MOD(NVL(c$.option$, 0), 2)
        FROM    sys.objauth$ c$, sys.obj$ o$, sys.user$ ur$, sys.user$ ue$,
                sys.table_privilege_map m$, sys.col$ cl$
        WHERE   c$.grantor# = ur$.user# AND
                c$.grantee# = ue$.user# AND
                c$.obj# = o$.obj# AND
                c$.privilege# = m$.privilege AND
                c$.obj# = cl$.obj# AND
                c$.col# = cl$.col#
/

