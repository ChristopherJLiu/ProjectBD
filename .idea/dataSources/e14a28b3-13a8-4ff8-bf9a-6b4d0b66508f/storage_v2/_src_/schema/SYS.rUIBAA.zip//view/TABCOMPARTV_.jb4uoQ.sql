CREATE VIEW TABCOMPARTV$ AS
  select obj#, dataobj#, bo#,
          row_number() over (partition by bo# order by part#),
          hiboundlen, hiboundval, subpartcnt, flags, defts#, defpctfree,
          defpctused, definitrans, defmaxtrans, definiexts,
          defextsize, defminexts, defmaxexts,defmaxsize,
          defextpct, deflists, defgroups,
          deflogging, defbufpool, analyzetime, samplesize, rowcnt, blkcnt,
          empcnt, avgspc, chncnt, avgrln, spare1, spare2, spare3, part#
from tabcompart$
/

