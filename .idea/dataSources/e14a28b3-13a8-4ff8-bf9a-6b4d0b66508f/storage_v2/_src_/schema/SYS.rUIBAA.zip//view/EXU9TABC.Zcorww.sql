CREATE VIEW EXU9TABC AS
  SELECT  t."OBJID",t."DOBJID",t."NAME",t."OWNER",t."OWNERID",t."TABLESPACE",t."TSNO",t."FILENO",t."BLOCKNO",t."AUDIT$",t."COMMENT$",t."CLUSTERFLAG",t."MTIME",t."MODIFIED",t."TABNO",t."PCTFREE$",t."PCTUSED$",t."INITRANS",t."MAXTRANS",t."DEGREE",t."INSTANCES",t."CACHE",t."TEMPFLAGS",t."PROPERTY",t."DEFLOG",t."TSDEFLOG",t."ROID",t."RECPBLK",t."SECONDARYOBJ",t."ROWCNT",t."BLKCNT",t."AVGRLEN",t."TFLAGS",t."TRIGFLAG",t."OBJSTATUS",t."XDBOOL"
        FROM    sys.exu9tab t, sys.incexp i, sys.incvid v
        WHERE   t.name = i.name(+) AND
                t.ownerid = i.owner#(+) AND
                NVL(i.type#, 2) = 2 AND
                BITAND(t.property, 8192) = 0 AND          /* not inner table */
                (BITAND(t.modified, 1) = 1 OR
                 i.itime > NVL(i.ctime, TO_DATE('01-01-1900', 'DD-MM-YYYY')) OR
                 t.mtime > i.itime OR
                 NVL(i.expid, 9999) > v.expid OR
                 /* determine if it has inner tables that have been
                 ** changed since last incremental export */
                 (BITAND(t.property, 4) = 4 AND          /* has inner tables */
                  EXISTS (
                    SELECT  0
                    FROM    sys.obj$ o2, sys.tab$ t2
                    WHERE   o2.obj# = t2.obj# AND
                            BITAND(t2.property, 8192) = 8192 AND
                            (o2.mtime > i.itime OR
                             BITAND(t2.flags, 1) = 1) AND
                            o2.obj# IN (
                                SELECT  nt.ntab#
                                FROM    sys.ntab$ nt
                                START WITH nt.obj# = t.objid
                                CONNECT BY PRIOR nt.ntab# = nt.obj#))))
/

