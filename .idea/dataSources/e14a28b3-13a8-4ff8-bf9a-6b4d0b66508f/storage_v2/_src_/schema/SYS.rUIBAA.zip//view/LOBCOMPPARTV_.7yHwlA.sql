CREATE VIEW LOBCOMPPARTV$ AS
  select partobj#, lobj#, tabpartobj#, indpartobj#,
          row_number() over (partition by lobj# order by part#),
          defts#, defchunk, defpctver$, defflags, defpro, definiexts,
          defextsize, defminexts, defmaxexts, defmaxsize, defretention,
          defmintime, defextpct, deflists,
          defgroups, defbufpool, spare1, spare2, spare3
from lobcomppart$
/

