CREATE VIEW EXU9TBCP AS
  SELECT  o.obj#, o.dataobj#, cp.bo#, o.owner#, o.subname, cp.part#,
                cp.hiboundlen, cp.hiboundval, NVL(cp.rowcnt, -1),
                NVL(cp.blkcnt, -1), NVL(cp.avgrln, -1), ts.name,
                MOD(cp.defpctfree, 100), cp.defpctused, cp.definitrans,
                cp.defmaxtrans, NVL(cp.definiexts, 0), NVL(cp.defextsize, 0),
                NVL(cp.defminexts, 0), NVL(cp.defmaxexts, 0),
                NVL(cp.defextpct, -1), NVL(cp.deflists, 0),
                NVL(cp.defgroups, 0),
                DECODE(bitand(cp.defbufpool,3), 1, 'KEEP', 2, 'RECYCLE', NULL),
                cp.deflogging, ts.dflogging, -1, -1, -1, -1, -1, -1,
                NVL(ts.blocksize, 2048), cp.spare2, NVL(cp.defmaxsize, 0),
                cp.flags
        FROM    sys.obj$ o, sys.tabcompart$ cp, sys.ts$ ts
        WHERE   cp.obj# = o.obj# AND
                cp.defts# = ts.ts# (+)
/

