CREATE VIEW EXU816MAXSQV AS
  SELECT  sv.version#, sv.sql_version
        FROM    sys.sql_version$ sv
        WHERE   sv.version# = (
                    SELECT  MAX(sv2.version#)
                    FROM    sys.sql_version$ sv2)
/

