CREATE VIEW EXU9COO_TTS_UNUSED_COL AS
  SELECT  tobjid, towner, townerid, v$.tname, v$.name, v$.length,
                v$.precision, v$.scale, v$.type, v$.isnull, v$.conname,
                v$.colid, v$.intcolid, v$.segcolid, v$.comment$, default$,
                v$.dfltlen, v$.enabled, v$.defer, v$.flags, v$.colprop,
                o$.name, u$.name, v$.charsetid, v$.charsetform, v$.fsprecision,
                v$.lfprecision, v$.charlen, NVL(ct$.flags,0), NULL
        FROM    sys.exu8col_temp_tts_unused_col v$, sys.col$ c$, sys.coltype$ ct$,
                sys.obj$ o$, sys.user$ u$
        WHERE   ((BITAND(v$.colprop, 32768) = 32768 AND /* unused col */
                  BITAND(v$.colprop, 1) != 1) OR        /* NOT ADT attr column */
                 (BITAND(v$.colprop, 32) != 32 OR       /* not a hidden column */
                 BITAND(v$.colprop, 1048608)= 1048608 OR/*snapshot hidden col*/
                 BITAND (v$.colprop, 4194304) = 4194304)) AND/* RLS hidden col*/
                v$.tobjid = c$.obj# (+) AND
                v$.intcolid = c$.intcol# (+) AND
                v$.tobjid = ct$.obj# (+) AND
                v$.intcolid = ct$.intcol# (+) AND
                NVL(ct$.toid, HEXTORAW('00')) = o$.oid$ (+) AND
                NVL(o$.owner#, -1) = u$.user# (+) AND
                NVL(o$.type#,13) = 13 AND
                ct$.synobj# IS NULL
      UNION ALL
        SELECT  tobjid, towner, townerid, v$.tname, v$.name, v$.length,
                v$.precision, v$.scale, v$.type, v$.isnull, v$.conname,
                v$.colid, v$.intcolid, v$.segcolid, v$.comment$, default$,
                v$.dfltlen, v$.enabled, v$.defer, v$.flags, v$.colprop,
                o$.name, u$.name, v$.charsetid, v$.charsetform,
                v$.fsprecision, v$.lfprecision, v$.charlen, NVL(ct$.flags,0),
                so$.name
        FROM    sys.exu8col_temp_tts_unused_col v$, sys.col$ c$, sys.coltype$ ct$,
                sys.obj$ o$, sys.user$ u$, sys.obj$ so$
        WHERE   ((BITAND(v$.colprop, 32768) = 32768 AND /* unused col */
                  BITAND(v$.colprop, 1) != 1) OR        /* NOT ADT attr column */
                (BITAND(v$.colprop, 32) != 32 OR        /* not a hidden column */
                 BITAND(v$.colprop, 1048608)= 1048608 OR/*snapshot hidden col*/
                 BITAND (v$.colprop, 4194304) = 4194304)) AND/* RLS hidden col*/
                v$.tobjid = c$.obj# (+) AND
                v$.intcolid = c$.intcol# (+) AND
                v$.tobjid = ct$.obj# (+) AND
                v$.intcolid = ct$.intcol# (+) AND
                NVL(ct$.toid, HEXTORAW('00')) = o$.oid$ (+) AND
                NVL(o$.owner#, -1) = u$.user# (+) AND
                NVL(o$.type#,13) = 13 AND so$.obj# = ct$.synobj#
/

