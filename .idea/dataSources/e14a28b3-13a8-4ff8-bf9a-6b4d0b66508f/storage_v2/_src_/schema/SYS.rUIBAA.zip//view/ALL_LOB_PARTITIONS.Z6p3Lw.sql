CREATE VIEW ALL_LOB_PARTITIONS AS
  select u.name,
       o.name,
       decode(bitand(c.property, 1), 1, a.name, c.name),
       lo.name,
       po.subname,
       lpo.subname,
       lipo.subname,
       row_number() over (partition by u.name, o.name,lo.name order by lf.frag#),
       'NO',
       lf.chunk * ts.blocksize,
       decode(bitand(lf.fragflags, 32), 0, lf.pctversion$, to_number(NULL)),
       decode(bitand(lf.fragflags, 795), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                         16, 'CACHEREADS', 256, 'YES', 512,
                                         'YES', 'YES'),
       decode(lf.fragpro, 0, 'NO', 2048, 'NO', 'YES'),
       ts.name,
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      ds.initial_stg, s.iniexts) * ts.blocksize),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      ds.next_stg, s.extsize) * ts.blocksize),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      ds.minext_stg, s.minexts)),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      ds.maxext_stg, s.maxexts)),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      ds.maxsiz_stg * ts.blocksize,
                      decode(bitand(s.spare1, 4194304), 4194304,
                             bitmapranges, NULL))),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      decode(bitand(lf.fragpro, 2048), 2048,
                             decode(ds.lobret_stg, to_number(NULL), 'DEFAULT',
                                                   0, 'NONE', 1, 'AUTO',
                                                   2, 'MIN',  3, 'MAX',
                                                   4, 'DEFAULT', 'INVALID'),
                             decode(bitand(lf.fragflags, 32), 32, 'YES',
                                                            'NO')),
                      decode(bitand(s.spare1, 2097152), 2097152,
                             decode(s.lists, 0, 'NONE', 1, 'AUTO',
                                             2, 'MIN', 3, 'MAX',
                                             4, 'DEFAULT', 'INVALID'),
                             decode(bitand(lf.fragflags, 32), 32, 'YES',
                                                            'NO')))),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                      decode(bitand(lf.fragpro, 2048), 2048,
                             ds.mintim_stg, NULL),
                      decode(bitand(s.spare1, 2097152), 2097152,
                             s.groups, NULL))),
       to_char(decode(bitand(ts.flags, 3), 1, to_number(NULL),
                     decode(bitand(lf.fragflags, 33554432), 33554432,
                           ds.pctinc_stg, s.extpct))),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                     decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                     decode(s.lists, 0, 1, s.lists))),
       to_char(decode(bitand(lf.fragflags, 33554432), 33554432,
                     decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                     decode(s.groups, 0, 1, s.groups))),
       decode(bitand(lf.fragflags, 786), 2,'NO', 16, 'NO', 256, 'NO', 512,
                                           'YES', 'YES'),
       decode(bitand(decode(bitand(lf.fragflags, 33554432), 33554432, ds.bfp_stg, s.cachehint), 3),
              1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(decode(bitand(lf.fragflags, 33554432), 33554432, ds.bfp_stg, s.cachehint), 12)/4,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(decode(bitand(lf.fragflags, 33554432), 33554432, ds.bfp_stg, s.cachehint), 48)/16,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(lf.fragflags,4096), 4096, 'YES',
              decode(bitand(lf.fragpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lf.fragflags,57344), 8192, 'LOW', 16384, 'MEDIUM',
              32768, 'HIGH',
              decode(bitand(lf.fragpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lf.fragflags,458752), 65536, 'LOB', 131072, 'OBJECT',
              327680, 'LOB VALIDATE', 393216, 'OBJECT VALIDATE',
              decode(bitand(lf.fragpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lf.fragpro,2048), 2048, 'YES', 'NO'),
       decode(bitand(lf.fragflags, 33554432), 33554432, 'NO', 'YES')
from   sys.obj$ o, sys.col$ c,
       sys.lob$ l, sys.obj$ lo,
       sys.lobfrag$ lf, sys.obj$ lpo,
       sys.obj$ po, sys.obj$ lipo,
       sys.partobj$ pobj, sys.tab$ t,
       sys.ts$ ts, sys.seg$ s, sys.user$ u, sys.attrcol$ a,
       sys.deferred_stg$ ds
where o.owner# = u.user#
  and pobj.obj# = o.obj#
  and o.obj# = t.obj#
  and bitand(t.trigflag, 1073741824) != 1073741824
  and mod(pobj.spare2, 256) = 0
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.lobj# = lf.parentobj#
  and lf.tabfragobj# = po.obj#
  and lf.fragobj# = lpo.obj#
  and lf.indfragobj# = lipo.obj#
  and lf.fragobj# = ds.obj#(+)
  and lf.ts# = s.ts#(+)
  and lf.file# = s.file#(+)
  and lf.block# = s.block#(+)
  and lf.ts# = ts.ts#
  and bitand(c.property,32768) != 32768           /* not unused column */
  and c.obj# = a.obj#(+) and c.intcol# = a.intcol#(+)
  and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
  and lo.namespace = 8 and lo.remoteowner IS NULL and lo.linkname IS NULL
  and ((o.owner# = userenv('SCHEMAID') and lo.owner# = userenv('SCHEMAID'))
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
      )
union all
select u.name,
       o.name,
       decode(bitand(c.property, 1), 1, a.name, c.name),
       lo.name,
       po.subname,
       lpo.subname,
       lipo.subname,
       row_number() over (partition by u.name, o.name,lo.name order by lcp.part#),
       'YES',
       lcp.defchunk,
       decode(bitand(lcp.defflags, 32), 0, lcp.defpctver$, to_number(NULL)),
       decode(bitand(lcp.defflags, 795), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                         16, 'CACHEREADS', 256, 'YES', 512,
                                         'YES', 'YES'),
       decode(lcp.defpro, 0, 'NO', 2048, 'NO', 'YES'),
       ts.name,
       decode(lcp.definiexts, NULL, 'DEFAULT', lcp.definiexts),
       decode(lcp.defextsize, NULL, 'DEFAULT', lcp.defextsize),
       decode(lcp.defminexts, NULL, 'DEFAULT', lcp.defminexts),
       decode(lcp.defmaxexts, NULL, 'DEFAULT', lcp.defmaxexts),
       decode(lcp.defmaxsize, NULL, 'DEFAULT', lcp.defmaxsize),
       decode(bitand(lcp.defpro, 2048), 2048,
               decode(lcp.defretention,
                      to_number(NULL), 'DEFAULT',
                      0, 'NONE',
                      1, 'AUTO',
                      2, 'MIN',
                      3, 'MAX',
                      4, 'DEFAULT',
                      'INVALID'),
               decode(bitand(lcp.defflags, 32), 32, 'YES', 'NO')),
       decode(lcp.defmintime, NULL, 'DEFAULT', lcp.defmintime),
       decode(lcp.defextpct,  NULL, 'DEFAULT', lcp.defextpct),
       decode(lcp.deflists,   NULL, 'DEFAULT', lcp.deflists),
       decode(lcp.defgroups,  NULL, 'DEFAULT', lcp.defgroups),
       decode(bitand(lcp.defflags, 790), 0,'NONE', 4,'YES', 2,'NO',
                                  16, 'NO', 256, 'NO', 512, 'YES', 'UNKNOWN'),
       decode(bitand(lcp.defbufpool, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(lcp.defbufpool, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(lcp.defbufpool, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(lcp.defflags,4096), 4096, 'YES',
              decode(bitand(lcp.defpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lcp.defflags,57344), 8192, 'LOW', 16384, 'MEDIUM', 32768,
              'HIGH',
              decode(bitand(lcp.defpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lcp.defflags,458752), 65536, 'LOB', 131072, 'OBJECT',
              327680, 'LOB VALIDATE', 393216, 'OBJECT VALIDATE',
              decode(bitand(lcp.defpro,2048), 2048, 'NO', 'NONE')),
       decode(bitand(lcp.defpro,2048), 2048, 'YES', 'NO'), 'N/A'
from   sys.obj$ o, sys.col$ c,
       sys.lob$ l, sys.obj$ lo,
       sys.lobcomppart$ lcp, sys.obj$ lpo,
       sys.obj$ po, sys.obj$ lipo,
       sys.ts$ ts, partobj$ pobj, sys.tab$ t, sys.user$ u, sys.attrcol$ a
where o.owner# = u.user#
  and pobj.obj# = o.obj#
  and o.obj# = t.obj#
  and bitand(t.trigflag, 1073741824) != 1073741824
  and mod(pobj.spare2, 256) != 0
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.lobj# = lcp.lobj#
  and lcp.tabpartobj# = po.obj#
  and lcp.partobj# = lpo.obj#
  and lcp.indpartobj# = lipo.obj#
  and lcp.defts# = ts.ts# (+)
  and bitand(c.property,32768) != 32768           /* not unused column */
  and c.obj# = a.obj#(+) and c.intcol# = a.intcol#(+)
  and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
  and lo.namespace = 8 and lo.remoteowner IS NULL and lo.linkname IS NULL
  and ((o.owner# = userenv('SCHEMAID') and lo.owner# = userenv('SCHEMAID'))
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
      )
/

