CREATE VIEW DBA_MVIEW_DETAIL_SUBPARTITION AS
  select u1.name owner, s.o1n mview_name , u2.name detailobj_owner,
         s.o2n detailobj_name,
         s.o3n  detail_partition_name,
         o5.subname detail_subpartition_name,
         tsv.subpart# detail_subpartition_position,
         (case when t.spare1 is NULL then 'FRESH'
               when t.spare1 < s.mv_scn then 'FRESH'
               else 'STALE' end) freshness
  from  sys.tabsubpart$ t,
  (select o1.owner# o1owner#, o1.name o1n,  o2.owner# o2owner#,
          o2.name o2n, o3.subname o3n,
          w.lastrefreshscn mv_scn,  o1.obj# as sumobj#, t.obj# as pobj#
   from sys.obj$ o1, sys.sum$ w, sys.sumdetail$ sd, sys.obj$ o2,
        sys.tabcompart$ t, sys.obj$ o3
   where w.obj# = o1.obj# and w.obj# = sd.sumobj#
         and sd.detailobj# = o2.obj# and sd.detailobj# = t.bo#
         and t.obj# = o3.obj#(+)
         and bitand(sd.detaileut, 2147483648) = 0/* NO secondary CUBE MV rows */) s,
  sys.tabsubpartv$ tsv, sys.user$ u1, sys.user$ u2, sys.obj$ o5
  where t.pobj# = s.pobj#
     and tsv.obj# = t.obj# and s.o1owner# = u1.user# and s.o2owner# = u2.user#
        and o5.obj# = t.obj#
/

