CREATE VIEW EXU81SPOK AS
  SELECT  o.obj#, o.owner#, spc.pos#,
                DECODE(BITAND(c.property, 1), 1, a.name, c.name),
                c.property, c.default$, c.deflength
        FROM    sys.obj$ o, sys.subpartcol$ spc, sys.col$ c, sys.attrcol$ a
        WHERE   o.obj# = c.obj# AND
                o.obj# = spc.obj# AND
                spc.intcol# = c.intcol# AND
                spc.obj# = a.obj# (+) AND
                spc.intcol# = a.intcol# (+)
/

