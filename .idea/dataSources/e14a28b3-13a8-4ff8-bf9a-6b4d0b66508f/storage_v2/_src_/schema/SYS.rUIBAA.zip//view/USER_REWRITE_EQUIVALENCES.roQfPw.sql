CREATE VIEW USER_REWRITE_EQUIVALENCES AS
  select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.user$ u
where u.name = m.owner
  and u.user# = userenv('SCHEMAID')
/

