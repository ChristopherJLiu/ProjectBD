CREATE VIEW EXU8COLNN AS
  SELECT  cc$.obj#, cc$.intcol#, con$.name, 1, NVL(cd$.enabled, 0),
                NVL(cd$.defer, 0)
        FROM    sys.con$ con$, sys.cdef$ cd$, sys.ccol$ cc$
        WHERE   cc$.con# = cd$.con# AND
                cd$.con# = con$.con# AND
                cd$.type# IN (7, 11)
/

