CREATE VIEW EXU8TAB AS
  SELECT  "OBJID","DOBJID","NAME","OWNER","OWNERID","TABLESPACE","TSNO","FILENO","BLOCKNO","AUDIT$","COMMENT$","CLUSTERFLAG","MTIME","MODIFIED","TABNO","PCTFREE$","PCTUSED$","INITRANS","MAXTRANS","DEGREE","INSTANCES","CACHE","TEMPFLAGS","PROPERTY","DEFLOG","TSDEFLOG","ROID","RECPBLK","SECONDARYOBJ","ROWCNT","BLKCNT","AVGRLEN","TFLAGS","TRIGFLAG","OBJSTATUS","XDBOOL"
        FROM    sys.exu81tab
        WHERE   NOT EXISTS (
                    SELECT  *
                    FROM    sys.col$ c$
                    WHERE   c$.obj# = objid AND
                            (c$.type# = 208 OR
                             (c$.type# >= 178 AND
                              c$.type# <= 183) OR
                             (c$.type# = 112 AND
                              ((c$.charsetid > 800 AND
                                c$.charsetid < 1000) OR
                               c$.charsetid > 2000))))
/

