CREATE VIEW EXU8TNTIC AS
  SELECT  o$.obj#, o$.owner#, o$.name
        FROM    sys.obj$ o$, sys.tab$ t$
        WHERE   (o$.owner#, o$.name) IN (
                    SELECT  i$.owner#, i$.name      /* tables in this export */
                    FROM    sys.incexp i$, sys.incvid v$
                    WHERE   i$.expid > v$.expid AND
                            i$.type# = 2) AND
                t$.obj# = o$.obj# AND
                BITAND(t$.property, 4) = 4              /* has nested tables */

