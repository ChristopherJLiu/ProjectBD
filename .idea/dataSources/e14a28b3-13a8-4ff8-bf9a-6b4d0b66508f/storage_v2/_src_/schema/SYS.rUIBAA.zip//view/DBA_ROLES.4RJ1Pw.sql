CREATE VIEW DBA_ROLES AS
  select name, decode(password, null,          'NO',
                              'EXTERNAL',    'EXTERNAL',
                              'GLOBAL',      'GLOBAL',
                              'YES'),
             decode(password, null,          'NONE',
                              'EXTERNAL',    'EXTERNAL',
                              'GLOBAL',      'GLOBAL',
                              'APPLICATION', 'APPLICATION',
                              'PASSWORD')
from  user$
where type# = 0 and name not in ('PUBLIC', '_NEXT_USER')
/

