CREATE VIEW DBA_AUDIT_EXISTS AS
  select os_username, username, userhost, terminal, timestamp,
         owner, obj_name,
         action_name,
         new_owner,
         new_name,
         obj_privilege, sys_privilege, grantee,
         sessionid, entryid, statementid, returncode, client_id,
         econtext_id, session_cpu,
         extended_timestamp, proxy_sessionid, global_uid, instance_number,
         os_process, transactionid, scn, sql_bind, sql_text, obj_edition_name
  from dba_audit_trail
  where returncode in
  (942, 943, 959, 1418, 1432, 1434, 1435, 1534, 1917, 1918, 1919, 2019,
   2024, 2289,
   4042, 4043, 4080, 1, 951, 955, 957, 1430, 1433, 1452, 1471, 1535, 1543,
   1758, 1920, 1921, 1922, 2239, 2264, 2266, 2273, 2292, 2297, 2378, 2379,
   2382, 4081, 12006, 12325)
/

