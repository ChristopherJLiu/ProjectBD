CREATE VIEW EXU8FUL AS
  SELECT  u.name
        FROM    sys.x$kzsro, sys.user$ u
        WHERE   kzsrorol != UID AND
                kzsrorol != 1 AND
                u.user# = kzsrorol
/

