CREATE VIEW DBA_MVIEW_DETAIL_PARTITION AS
  select u1.name owner, o1.name mview_name,
       u2.name detailobj_owner, o2.name detailobj_name,
       o3.subname detail_partition_name,
       tv.part# detail_partition_position,
       (case when t.spare1 is NULL then 'FRESH'
             when t.spare1 < w.lastrefreshscn then 'FRESH'
             else 'STALE' end) freshness
from sys.obj$ o1, sys.sum$ w, sys.sumdetail$ sd, sys.obj$ o2, sys.tabpart$ t,
     sys.obj$ o3, sys.tabpartv$ tv, sys.user$ u1, sys.user$ u2
where w.obj# = o1.obj#
  and w.obj# = sd.sumobj#
  and sd.detailobj# = o2.obj#
  and sd.detailobj# = t.bo#
  and t.obj# = o3.obj#(+)
  and t.obj# = tv.obj#(+)
  and o1.owner# = u1.user#
  and o2.owner# = u2.user#
  and bitand(sd.detaileut, 2147483648) = 0 /* NOT 2nd cube mv pct metadata */

