CREATE VIEW ALL_REFRESH_DEPENDENCIES AS
  select u.name, o.name, 'MATERIALIZED VIEW', dep.lastrefreshscn,
       dep.lastrefreshdate
from (select dt.obj#,
             min(dt.lastrefreshscn) as lastrefreshscn,
             min(dt.lastrefreshdate) as lastrefreshdate
      from
           (select d.p_obj# as obj#, s.lastrefreshscn, s.lastrefreshdate
            from sumdep$ d, sum$ s, obj$ do
            where d.sumobj# = s.obj#
              and d.sumobj# = do.obj#
              and do.type# IN (4, 42)
            union
            select sl.tableobj# as obj#,
                   decode(0, 1, 2, NULL) as lastrefreshscn,
                   sl.oldest  as lastrefreshdate
            from snap_loadertime$ sl) dt
      group by dt.obj#) dep, obj$ o, user$ u
where o.obj# = dep.obj#
  and o.owner# = u.user#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in (select oa.obj# from sys.objauth$ oa
                     where grantee# in (select kzsrorol from x$kzsro)
                    )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/

