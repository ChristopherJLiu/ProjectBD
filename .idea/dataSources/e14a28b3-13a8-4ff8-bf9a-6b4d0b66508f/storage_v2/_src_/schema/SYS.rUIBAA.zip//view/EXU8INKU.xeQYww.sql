CREATE VIEW EXU8INKU AS
  SELECT  "OBJID","OWNERID","INTCOLID","NAME"
        FROM    sys.exu8ink
        WHERE   ownerid = UID
/

