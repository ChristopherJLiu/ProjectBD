CREATE VIEW EXU8TBP AS
  SELECT  o$.obj#, o$.dataobj#, tp$.bo#, o$.owner#, o$.subname,
                NVL(tp$.rowcnt, -1), NVL(tp$.blkcnt, -1), NVL(tp$.avgrln, -1),
                tp$.flags, tp$.part#, tp$.hiboundlen, tp$.hiboundval, ts$.name,
                tp$.ts#, tp$.file#, tp$.block#, MOD(tp$.pctfree$, 100),
                tp$.pctused$, tp$.initrans, tp$.maxtrans,
                DECODE(BITAND(tp$.flags, 4), 4, 1, 0), ts$.dflogging, -1, -1,
                -1, -1, -1, -1, -1
        FROM    sys.obj$ o$, sys.tabpart$ tp$, sys.ts$ ts$
        WHERE   o$.type# = 19 AND
                tp$.obj# = o$.obj# AND
                ts$.ts# = tp$.ts#
/

