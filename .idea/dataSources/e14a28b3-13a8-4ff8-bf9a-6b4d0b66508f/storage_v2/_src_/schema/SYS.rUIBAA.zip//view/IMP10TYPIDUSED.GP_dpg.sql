CREATE VIEW IMP10TYPIDUSED AS
  SELECT typeid, toid, roottoid
        FROM sys.type$
/

