CREATE VIEW ALL_CHANGE_PROPAGATION_SETS AS
  SELECT
   p.sourceid_name, p.propagation_name, p.staging_database,
   s.change_set_publisher, s.change_set_name
  FROM sys.cdc_propagations$ p, sys.cdc_propagated_sets$ s
  WHERE s.propagation_name = p.propagation_name
/

