CREATE VIEW EXU8VINFC AS
  SELECT  vw."VOBJID",vw."VNAME",vw."VTEXT",vw."VOWNER",vw."VOWNERID",vw."VAUDIT",vw."VCOMMENT",vw."VCNAME",vw."PROPERTY",vw."DEFER",vw."FLAGS",vw."OIDLEN",vw."OIDCLAUSE",vw."TYPEOWNER",vw."TYPENAME",vw."VLEN"
        FROM    sys.exu8vinf vw, sys.incexp i, sys.incvid v
        WHERE   vw.vname = i.name(+) AND
                vw.vownerid = i.owner#(+) AND
                NVL(i.type#, 4) = 4 AND
                (NVL(i.ctime, TO_DATE('01-01-1900', 'DD-MM-YYYY')) < i.itime OR
                v.expid < NVL(i.expid, 9999))
/

