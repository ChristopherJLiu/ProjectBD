CREATE VIEW IMP8TTD AS
  SELECT  o$.name, u$.name, o$.oid$
        FROM    sys.obj$ o$, sys.user$ u$, sys.type$ t$
        WHERE   o$.type# = 13 AND
                o$.owner# = u$.user# AND
                o$.oid$   = t$.toid  AND
                t$.toid   = t$.tvoid                          /* Only latest */

