CREATE VIEW EXU8GRS AS
  SELECT  t$.obj#, o$.name
        FROM    sys.objauth$ t$, sys.obj$ o$
        WHERE   o$.obj# = t$.obj# AND
                t$.col# IS NULL AND
                t$.grantor# = 0 AND
                o$.type# NOT IN (
                    SELECT  type#
                    FROM    sys.exppkgobj$)
/

