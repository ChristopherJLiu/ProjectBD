CREATE VIEW EXU8TNTI AS
  SELECT  objid, ownerid, name
        FROM    sys.exu8tabi                        /* tables in this export */
        WHERE   BITAND(property, 4) = 4           /* table has nested tables */

