CREATE VIEW ALL_REWRITE_EQUIVALENCES AS
  select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and m.name   = o.name
  and u.name   = m.owner
  and ( o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/

