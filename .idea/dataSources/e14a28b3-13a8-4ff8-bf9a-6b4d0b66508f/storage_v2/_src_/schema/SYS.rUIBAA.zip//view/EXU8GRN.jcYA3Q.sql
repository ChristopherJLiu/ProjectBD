CREATE VIEW EXU8GRN AS
  SELECT  t$.obj#, ur$.name, t$.grantor#, ue$.name, m$.name,
                MOD(NVL(t$.option$/2, 0), 2), MOD(NVL(t$.option$, 0), 2),
                o$.owner#, t$.sequence#,
                DECODE ((o$.type#), 23, 1, 0), o$.type#
        FROM    sys.objauth$ t$, sys.obj$ o$, sys.user$ ur$,
                sys.table_privilege_map m$, sys.user$ ue$
        WHERE   o$.obj# = t$.obj# AND
                t$.privilege# = m$.privilege AND
                t$.col# IS NULL AND
                t$.grantor# = ur$.user# AND
                t$.grantee# = ue$.user# AND
                ue$.name NOT IN ('ORDSYS',  'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                                 'LBACSYS', 'XDB',   'SI_INFORMTN_SCHEMA',
                                 'DIP',   'DBSNMP', 'EXFSYS', 'WMSYS',
                                 'ORACLE_OCM', 'ANONYMOUS', 'XS$NULL',
                                 'APPQOSSYS')
/

