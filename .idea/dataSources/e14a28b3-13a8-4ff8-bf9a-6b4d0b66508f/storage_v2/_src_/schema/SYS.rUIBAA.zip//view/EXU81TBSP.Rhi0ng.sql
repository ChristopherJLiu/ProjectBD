CREATE VIEW EXU81TBSP AS
  SELECT  o.obj#, o.dataobj#, sp.pobj#, o.owner#, sp.subpart#, o.subname,
                ts.name, sp.file#, sp.block#, sp.ts#, NVL(sp.rowcnt, -1),
                NVL(sp.blkcnt, -1), NVL(sp.avgrln, -1), -1, -1, -1, -1, -1, -1,
                sp.hiboundlen, sp.hiboundval, sp.flags
        FROM    sys.obj$ o, sys.tabsubpart$ sp, sys.ts$ ts
        WHERE   o.type# = 34 AND
                sp.obj# = o.obj# AND
                ts.ts# = sp.ts#
/

