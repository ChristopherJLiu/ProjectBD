CREATE VIEW EXU8IOV AS
  SELECT  o$.obj#, o$.dataobj#, o$.name, t$.bobj#, u$.name, o$.owner#,
                ts$.name, t$.ts#, t$.file#, t$.block#, t$.audit$, c$.comment$,
                NVL(t$.bobj#, 0), o$.mtime,
                DECODE(BITAND(t$.flags, 1), 1, 1, 0), MOD(t$.pctfree$, 100),
                t$.pctused$, t$.initrans, t$.maxtrans, NVL(t$.degree, 1),
                NVL(t$.instances, 1), DECODE(BITAND(t$.flags, 128), 128, 1, 0),
                MOD(TRUNC(o$.flags / 2), 2), t$.property,
                DECODE(BITAND(t$.flags, 32), 32, 1, 0), ts$.dflogging
        FROM    sys.tab$ t$, sys.obj$ o$, sys.ts$ ts$, sys.user$ u$,
                sys.com$ c$
        WHERE   t$.obj# = o$.obj# AND
                t$.ts# = ts$.ts# AND
                u$.user# = o$.owner# AND
                o$.obj# = c$.obj#(+) AND
                c$.col#(+) IS NULL AND
                BITAND(t$.property, 512) = 512
/

