CREATE VIEW INDSUBPARTV$ AS
  select obj#, dataobj#, pobj#,
          row_number() over (partition by pobj# order by subpart#),
          flags, ts#, file#, block#, pctfree$,
          initrans, maxtrans, analyzetime, samplesize, rowcnt, blevel, leafcnt,
          distkey, lblkkey, dblkkey, clufac, spare1, spare2, spare3,
          hiboundlen, hiboundval, subpart#
from indsubpart$
/

