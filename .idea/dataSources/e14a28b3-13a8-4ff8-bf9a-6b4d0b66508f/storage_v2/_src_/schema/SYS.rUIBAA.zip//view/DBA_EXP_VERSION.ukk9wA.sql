CREATE VIEW DBA_EXP_VERSION AS
  select o.expid
from sys.incvid o
/

