CREATE VIEW EXU8POKI AS
  SELECT  o.obj#, o.owner#, p.pos#,
                DECODE(BITAND(c.property, 1), 1, a.name, c.name),
                c.property, c.default$, c.deflength
        FROM    sys.obj$ o, sys.partcol$ p, sys.ind$ i, sys.col$ c,
                sys.attrcol$ a
        WHERE   o.obj# = p.obj# AND
                i.obj# = o.obj# AND
                i.bo# = c.obj# AND
                p.intcol# = c.intcol# AND
                c.obj# = a.obj# (+) AND
                c.intcol# = a.intcol# (+)
/

