CREATE VIEW IMP8CDTU AS
  SELECT  "OWNERID","BAD"
        FROM    sys.imp8cdt
        WHERE   ownerid = UID
/

