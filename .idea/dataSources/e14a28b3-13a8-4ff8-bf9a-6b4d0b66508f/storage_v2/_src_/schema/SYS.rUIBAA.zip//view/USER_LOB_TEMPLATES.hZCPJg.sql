CREATE VIEW USER_LOB_TEMPLATES AS
  select o.name, decode(bitand(c.property, 1), 1, ac.name, c.name),
       st.spart_name, lst.lob_spart_name, ts.name
from sys.obj$ o, sys.defsubpart$ st, sys.defsubpartlob$ lst, sys.ts$ ts,
     sys.col$ c, sys.attrcol$ ac
where o.obj# = lst.bo# and st.bo# = lst.bo# and
      st.spart_position =  lst.spart_position and
      lst.lob_spart_ts# = ts.ts#(+) and c.obj# = lst.bo# and
      c.intcol# = lst.intcol# and o.owner# = userenv('SCHEMAID') and
      o.subname IS NULL and
      o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
      lst.intcol# = ac.intcol#(+) and lst.bo# = ac.obj#(+)
/

