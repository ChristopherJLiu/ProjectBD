CREATE VIEW EXU8IXP AS
  SELECT  o$.obj#, o$.dataobj#, ip$.bo#, o$.owner#, o$.subname,
                NVL(ip$.rowcnt, -1),
                NVL2((
                    SELECT  i$.bo#
                    FROM    sys.ind$ i$
                    WHERE   i$.type# = 4 AND
                            i$.obj# = ip$.bo#),
                    NVL(ip$.leafcnt, -1), -1),  /* leafcnt (blkcnt) if table */
                NVL((
                    SELECT  tp$.avgrln
                    FROM    sys.tabpart$ tp$              /* avglen if table */
                    WHERE   tp$.part# = ip$.part# AND
                            tp$.bo# = (
                                SELECT  i$.bo#
                                FROM    sys.ind$ i$
                                WHERE   i$.type# = 4 AND        /* iot - top */
                                        i$.obj# = ip$.bo#)), -1),
                NVL2((
                    SELECT  i$.bo#
                    FROM    sys.ind$ i$              /* stats flags if table */
                    WHERE   i$.type# = 4 AND
                            i$.obj# = ip$.bo#),
                    ip$.flags, -1),
                ip$.part#, ip$.hiboundlen, ip$.hiboundval, ts$.name, ip$.ts#,
                ip$.file#, ip$.block#, MOD(ip$.pctfree$, 100), 0, ip$.initrans,
                ip$.maxtrans, DECODE(BITAND(ip$.flags, 4), 4, 1, 0),
                ts$.dflogging, NVL(ip$.blevel, -1), NVL(ip$.leafcnt, -1),
                NVL(ip$.distkey, -1), NVL(ip$.lblkkey, -1),
                NVL(ip$.dblkkey, -1), NVL(ip$.clufac, -1), ip$.flags
        FROM    sys.obj$ o$, sys.indpart$ ip$, sys.ts$ ts$
        WHERE   o$.type# = 20 AND
                ip$.obj# = o$.obj# AND
                ts$.ts# = ip$.ts#
/

