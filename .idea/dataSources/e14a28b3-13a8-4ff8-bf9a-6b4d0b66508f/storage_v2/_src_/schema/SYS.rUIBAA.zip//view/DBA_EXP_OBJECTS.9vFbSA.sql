CREATE VIEW DBA_EXP_OBJECTS AS
  select u.name, o.name,
       decode(o.type#, 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE', 7, 'PROCEDURE',
                      8, 'FUNCTION', 9, 'PACKAGE', 11, 'PACKAGE BODY',
                      12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
                      22, 'LIBRARY', 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
                      30, 'JAVA RESOURCE', 87, 'ASSEMBLY', 'UNDEFINED'),
       o.ctime, o.itime, o.expid
from sys.incexp o, sys.user$ u
where o.owner# = u.user#
/

