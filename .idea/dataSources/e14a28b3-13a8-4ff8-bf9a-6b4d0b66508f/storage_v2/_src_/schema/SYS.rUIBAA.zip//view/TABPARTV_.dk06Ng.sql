CREATE VIEW TABPARTV$ AS
  select obj#, dataobj#, bo#,
          row_number() over (partition by bo# order by part#),
          hiboundlen, hiboundval, ts#, file#, block#, pctfree$, pctused$,
          initrans, maxtrans, flags, analyzetime, samplesize, rowcnt, blkcnt,
          empcnt, avgspc, chncnt, avgrln, part#
from tabpart$
/

