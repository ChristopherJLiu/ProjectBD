CREATE VIEW EXU81IXSP AS
  SELECT  o.obj#, o.dataobj#, isp.pobj#, o.owner#, isp.subpart#,
                o.subname, ts.name, isp.file#, isp.block#, isp.ts#,
                NVL(isp.rowcnt, -1), -1, -1, NVL(isp.blevel, -1),
                NVL(isp.leafcnt, -1), NVL(isp.distkey, -1),
                NVL(isp.lblkkey, -1), NVL(isp.dblkkey, -1),
                NVL(isp.clufac, -1), isp.hiboundlen, isp.hiboundval, isp.flags
        FROM    sys.obj$ o, sys.indsubpart$ isp, sys.ts$ ts
        WHERE   o.type# = 35 AND
                isp.obj# = o.obj# AND
                ts.ts# = isp.ts#
/

