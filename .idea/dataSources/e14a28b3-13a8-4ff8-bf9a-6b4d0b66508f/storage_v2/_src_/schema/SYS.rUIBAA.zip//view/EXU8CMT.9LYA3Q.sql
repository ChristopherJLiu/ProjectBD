CREATE VIEW EXU8CMT AS
  SELECT  o$.owner#, cm$.obj#, cm$.col#, c$.name, cm$.comment$
        FROM    sys.com$ cm$, sys.obj$ o$, sys.col$ c$
        WHERE   o$.obj# = cm$.obj# AND
                c$.obj# = cm$.obj# AND
                c$.intcol# = cm$.col#
/

