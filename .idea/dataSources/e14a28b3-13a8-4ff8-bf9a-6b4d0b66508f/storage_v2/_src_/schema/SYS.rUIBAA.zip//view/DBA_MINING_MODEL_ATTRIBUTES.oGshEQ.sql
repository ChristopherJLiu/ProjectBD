CREATE VIEW DBA_MINING_MODEL_ATTRIBUTES AS
  select u.name, o.name, a.name,
       decode(atyp, /* attribute type */
              1, 'NUMERICAL',
              2, 'CATEGORICAL',
              3, 'ORDINAL',
                 'UNDEFINED'),
       decode(dtyp, /* data type */
              1, 'VARCHAR2',
              2, 'NUMBER',
              4, 'FLOAT',
             96, 'CHAR',
            122, 'NESTED TABLE',
                 'UNDEFINED'),
       a.length,
       a.precision#,
       a.scale,
       decode(bitand(a.properties,1),1,'ACTIVE','INACTIVE'),
       decode(bitand(a.properties,2),2,'YES','NO')
from sys.modelatt$ a, sys.obj$ o, sys.user$ u
where o.obj#=a.mod#
  and o.owner#=u.user#
  and bitand(a.properties, 4) = 0
/

