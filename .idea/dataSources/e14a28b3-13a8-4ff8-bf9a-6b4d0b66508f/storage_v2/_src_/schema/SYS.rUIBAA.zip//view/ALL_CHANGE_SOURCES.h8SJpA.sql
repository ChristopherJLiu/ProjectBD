CREATE VIEW ALL_CHANGE_SOURCES AS
  SELECT
   s.source_name, s.dbid, s.logfile_location, s.logfile_suffix,
   s.source_description, s.created,
   decode(bitand(s.source_type, 206),
                         2, 'AUTOLOG',
                         4, 'HOTLOG',
                         8, 'SYNCHRONOUS',
                        68, 'DISTRIBUTED HOTLOG',
                       130, 'AUTOLOG ONLINE',
                            'UNKNOWN'),
   s.source_database, s.first_scn, s.publisher,
   s.capture_name, s.capqueue_name, s.capqueue_tabname,
   s.source_enabled
  FROM sys.cdc_change_sources$ s
/

