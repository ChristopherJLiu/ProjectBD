CREATE VIEW EXU9DOI AS
  SELECT  ind$.obj#, indo$.owner#, ind$.spare4, o2$.name, u2$.name,
                o3$.name, u3$.name, it$.interface_version#, it$.property, 0
        FROM    sys.ind$ ind$, sys.obj$ indo$, sys.obj$ o2$, sys.obj$ o3$,
                sys.user$ u2$, sys.user$ u3$, sys.indtypes$ it$
        WHERE   ind$.type# = 9 AND                           /* Domain Index */
                ind$.indmethod# = it$.obj#  AND
                ind$.obj# = indo$.obj# AND
                it$.obj# = o2$.obj# AND
                it$.implobj# = o3$.obj# AND
                o2$.owner# = u2$.user# AND
                o3$.owner# = u3$.user# AND
                BITAND(ind$.property, 2) != 2                 /* partitioned */
      UNION ALL         /* Grab domain indexes that have partition info also */
        SELECT  ind$.obj#, indo$.owner#, ind$.spare4, o2$.name, u2$.name,
                o3$.name, u3$.name, it$.interface_version#, it$.property,
                DECODE(BITAND (ind$.property, 512), 512, 64,0)+/*0x200=iot di*/
                DECODE(BITAND(po$.flags, 1), 1, 1, 0) +         /* 1 = local */
                DECODE(po$.parttype, 1, 2, 2, 4, 0)   /* 1 = range, 2 = hash */
        FROM    sys.ind$ ind$, sys.obj$ indo$, sys.obj$ o2$, sys.obj$ o3$,
                sys.user$ u2$, sys.user$ u3$, sys.indtypes$ it$,
                sys.partobj$ po$
        WHERE   ind$.type# = 9 AND
                ind$.indmethod# = it$.obj# AND
                ind$.obj# = indo$.obj# AND
                it$.obj# = o2$.obj# AND
                it$.implobj# = o3$.obj# AND
                o2$.owner# = u2$.user# AND
                o3$.owner# = u3$.user# AND
                BITAND(po$.flags, 8) = 8 AND
                po$.obj# = ind$.obj# AND
                BITAND(ind$.property, 2) = 2                  /* partitioned */

