CREATE VIEW DBA_SOURCE_TABLES AS
  SELECT DISTINCT
   s.source_schema_name, s.source_table_name
  FROM sys.cdc_change_tables$ s, dba_tables t
  WHERE s.change_table_schema=t.owner AND
        s.change_table_name=t.table_name
/

