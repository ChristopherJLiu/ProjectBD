CREATE VIEW EXU81TBCP AS
  SELECT  p.objid, p.dobjid, p.bobjid, p.ownerid, p.compname, p.partno,
                p.hiboundlen, p.hiboundval, p.prowcnt, p.pblkcnt, p.pavgrlen,
                p.tsname, p.pctfree$, p.pctused$, p.initrans, p.maxtrans,
                CEIL(p.iniexts * (p.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                CEIL(p.extsize * (p.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                p.minexts, p.maxexts, p.extpct, p.flists, p.freegrp, p.pcache,
                p.deflog, p.tsdeflog, p.blevel, p.leafcnt, p.distkey,
                p.lblkkey, p.dblkkey, p.clufac
        FROM    sys.exu9tbcp p
/

