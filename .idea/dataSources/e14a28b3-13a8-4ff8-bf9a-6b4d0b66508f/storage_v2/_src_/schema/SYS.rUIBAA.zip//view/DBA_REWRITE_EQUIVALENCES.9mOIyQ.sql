CREATE VIEW DBA_REWRITE_EQUIVALENCES AS
  select u.name, o.name, s.src_stmt, s.dest_stmt,
       decode(s.rw_mode, 0, 'DISABLED',
                         1, 'TEXT_MATCH',
                         2, 'GENERAL',
                         3, 'RECURSIVE',
                         4, 'TUNE_MVIEW',
                         'UNDEFINED')
from sum$ s, obj$ o, user$ u
  where o.obj# = s.obj# and
  bitand(s.xpflags, 8388608) > 0 and  /* REWRITE EQUIVALENCE SUMMARY */
  o.owner# = u.user#
/

