CREATE VIEW EXU8VEWI AS
  SELECT  vw."VOBJID",vw."VNAME",vw."VTEXT",vw."VOWNER",vw."VOWNERID",vw."VAUDIT",vw."VCOMMENT",vw."VCNAME",vw."VLEVEL",vw."PROPERTY",vw."DEFER",vw."FLAGS",vw."OIDLEN",vw."OIDCLAUSE",vw."TYPEOWNER",vw."TYPENAME",vw."VLEN",vw."SQLVER",vw."UNDERLEN",vw."UNDERCLAUSE"
        FROM    sys.exu8vew vw, sys.incexp i, sys.incvid v
        WHERE   i.name(+) = vw.vname AND
                i.owner#(+) = vw.vownerid AND
                v.expid < NVL(i.expid, 9999) AND
                NVL(i.type#, 4) = 4
/

