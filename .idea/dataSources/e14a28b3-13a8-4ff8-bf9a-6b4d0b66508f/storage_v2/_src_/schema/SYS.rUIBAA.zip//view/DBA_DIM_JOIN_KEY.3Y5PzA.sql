CREATE VIEW DBA_DIM_JOIN_KEY AS
  select u.name, o.name, djk.joinkeyid#, dl.levelname,
       djk.keypos#, h.hiername, u1.name, o1.name, c.name, dl2.levelname
from sys.dimjoinkey$ djk, sys.obj$ o, sys.user$ u,
     sys.dimlevel$ dl, sys.hier$ h, sys.col$ c, sys.obj$ o1, sys.user$ u1,
     sys.dimlevel$ dl2
where djk.dimobj# = o.obj#
  and o.owner# = u.user#
  and djk.dimobj# = dl.dimobj#
  and djk.levelid# = dl.levelid#
  and djk.dimobj# = h.dimobj#
  and djk.hierid# = h.hierid#
  and djk.detailobj# = c.obj#
  and djk.col# = c.intcol#
  AND djk.detailobj# = o1.obj#
  AND o1.owner# = u1.user#
  AND djk.dimobj# = dl2.dimobj#
  AND djk.chdlevid# = dl2.levelid#
/

