CREATE VIEW EXU8VDPT AS
  SELECT  d$.p_obj#, d$.d_obj#, o1$.owner#, o2$.owner#
        FROM    sys.dependency$ d$, sys.obj$ o1$, sys.obj$ o2$, sys.view$ v1$,
                sys.view$ v2$
        WHERE   d$.p_obj# = v1$.obj# AND
                v1$.obj# = o1$.obj# AND
                d$.d_obj# = v2$.obj# AND
                v2$.obj# = o2$.obj#
/

