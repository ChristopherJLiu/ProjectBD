CREATE VIEW DBA_DIM_CHILD_OF AS
  select u.name, o.name, h.hiername, chl.pos#,
       cdl.levelname,
       decode(phl.joinkeyid#, 0, NULL, phl.joinkeyid#),
       pdl.levelname
from sys.obj$ o, sys.user$ u, sys.hier$ h,
     sys.hierlevel$ phl, sys.hierlevel$ chl,
     sys.dimlevel$ pdl,  sys.dimlevel$ cdl
where phl.dimobj# = o.obj#
  and o.owner# = u.user#
  and phl.dimobj# = h.dimobj#
  and phl.hierid# = h.hierid#
  and phl.dimobj# = pdl.dimobj#
  and phl.levelid# = pdl.levelid#
  and phl.dimobj# = chl.dimobj#
  and phl.hierid# = chl.hierid#
  and phl.pos# = chl.pos# + 1
  and chl.dimobj# = cdl.dimobj#
  and chl.levelid# = cdl.levelid#
  AND (phl.joinkeyid# = 0
       OR (phl.joinkeyid# NOT IN
             (SELECT DISTINCT d.joinkeyid#
                FROM sys.dimjoinkey$ d
                WHERE phl.dimobj# = d.dimobj# AND phl.joinkeyid# = d.joinkeyid#
                      AND d.chdlevid# != chl.levelid#
             )
          )
      )
/

