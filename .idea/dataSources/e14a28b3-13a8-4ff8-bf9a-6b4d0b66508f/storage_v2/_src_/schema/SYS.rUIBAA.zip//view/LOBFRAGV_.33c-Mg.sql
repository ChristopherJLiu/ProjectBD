CREATE VIEW LOBFRAGV$ AS
  select fragobj#, parentobj#, tabfragobj#, indfragobj#,
          row_number() over (partition by parentobj# order by frag#),
          fragtype$, ts#, file#, block#, chunk, pctversion$, fragflags,
          fragpro, spare1, spare2, spare3
from lobfrag$
/

