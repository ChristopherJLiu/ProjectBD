CREATE VIEW ALL_MVIEW_DETAIL_SUBPARTITION AS
  select m."OWNER",m."MVIEW_NAME",m."DETAILOBJ_OWNER",m."DETAILOBJ_NAME",m."DETAIL_PARTITION_NAME",m."DETAIL_SUBPARTITION_NAME",m."DETAIL_SUBPARTITION_POSITION",m."FRESHNESS" from dba_mview_detail_subpartition m, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and m.mview_name = o.name
  and u.name       = m.owner
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/

