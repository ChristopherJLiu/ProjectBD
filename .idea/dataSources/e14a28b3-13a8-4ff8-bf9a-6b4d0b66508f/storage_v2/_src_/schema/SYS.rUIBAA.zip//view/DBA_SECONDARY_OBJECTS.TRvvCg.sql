CREATE VIEW DBA_SECONDARY_OBJECTS AS
  select u.name, o.name, u1.name, o1.name, decode(s.spare1, 0, 'FROM INDEXTYPE',
                                                1, 'FROM STATISTICS TYPE')
from   sys.user$ u, sys.obj$ o, sys.user$ u1, sys.obj$ o1, sys.secobj$ s
where  s.obj# = o.obj# and o.owner# = u.user# and
       s.secobj# = o1.obj#  and  o1.owner# = u1.user#
/

