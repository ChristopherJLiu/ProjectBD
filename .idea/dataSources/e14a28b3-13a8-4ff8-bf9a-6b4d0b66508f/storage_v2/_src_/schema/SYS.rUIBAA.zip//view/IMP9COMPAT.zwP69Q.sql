CREATE VIEW IMP9COMPAT AS
  SELECT  value
        FROM    v$parameter
        WHERE   name = 'compatible'
/

