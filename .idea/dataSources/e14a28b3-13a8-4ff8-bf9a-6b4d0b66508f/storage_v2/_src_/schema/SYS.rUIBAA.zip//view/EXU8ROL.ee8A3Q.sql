CREATE VIEW EXU8ROL AS
  SELECT  name, password
        FROM    sys.user$
        WHERE   type# = 0 AND
                name NOT IN ('CONNECT', 'RESOURCE', 'DBA', 'PUBLIC',
                             '_NEXT_USER', 'EXP_FULL_DATABASE',
                             'IMP_FULL_DATABASE')
/

