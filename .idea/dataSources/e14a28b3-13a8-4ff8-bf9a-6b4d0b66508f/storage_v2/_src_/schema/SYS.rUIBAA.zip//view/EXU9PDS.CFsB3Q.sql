CREATE VIEW EXU9PDS AS
  SELECT  o$.obj#, o$.type#, o$.owner#, po$.parttype,
                MOD(po$.spare2, 256), NVL(po$.flags, 0), po$.partcnt,
                po$.partkeycols, MOD(po$.defpctfree, 100), po$.defpctused,
                po$.definitrans, po$.defmaxtrans, po$.deftiniexts,
                po$.defextsize, po$.defminexts, po$.defmaxexts, po$.defextpct,
                po$.deflists, po$.defgroups, ts$.name, po$.deflogging,
                DECODE(bitand(po$.spare1,3), 1, 'KEEP', 2, 'RECYCLE', NULL),
                NVL(ts$.blocksize, 2048),      /* non null for table/indexes */
                (po$.spare2/4294967296),  /* divide by ^x80000000 for byte 4 */
                MOD(TRUNC(po$.spare2/65536), 65536), po$.defmaxsize
        FROM    sys.partobj$ po$, sys.obj$ o$, sys.ts$ ts$
        WHERE   po$.defts# = ts$.ts# (+) AND
                po$.obj# = o$.obj#
/

