CREATE VIEW EXU10COE AS
  SELECT  "TOBJID","TOWNER","TOWNERID","TNAME","NAME","LENGTH","PRECISION","SCALE","TYPE","ISNULL","CONNAME","COLID","INTCOLID","SEGCOLID","COMMENT$","DEFAULT$","DFLTLEN","ENABLED","DEFER","FLAGS","COLPROP","ADTNAME","ADTOWNER","COLCLASS","CHARSETID","CHARSETFORM","FSPRECISION","LFPRECISION","CHARLEN","TFLAGS","TYPESYN"
        FROM    sys.exu9coe
      UNION ALL
        SELECT  tobjid, towner, townerid, v$.tname, v$.name, v$.length,
                v$.precision, v$.scale, v$.type, v$.isnull, v$.conname,
                v$.colid, v$.intcolid, v$.segcolid, v$.comment$, default$,
                v$.dfltlen, v$.enabled, v$.defer, v$.flags, v$.colprop,
                o$.name, u$.name,
                DECODE (v$.name, 'SYS_NC_OID$', 1, 'NESTED_TABLE_ID', 2,
                        'SYS_NC_ROWINFO$', 3, 100),
                v$.charsetid, v$.charsetform, v$.fsprecision, v$.lfprecision,
                v$.charlen, NVL(ct$.flags, 0), NULL
        FROM    sys.exu8col_temp v$, sys.col$ c$, sys.coltype$ ct$,
                sys.obj$ o$, sys.user$ u$
        WHERE   c$.obj# = v$.tobjid AND
                c$.intcol# = v$.intcolid AND
                c$.intcol# = ct$.intcol# (+) AND
                (BITAND(v$.colprop, 32)      != 32 OR          /* not hidden */
                 BITAND(v$.colprop, 1048608) = 1048608 OR  /* snapsht hidden */
                 BITAND(v$.colprop, 4194304) = 4194304) AND    /* RLS Hidden */
                c$.obj# = ct$.obj# (+) AND
                NVL(ct$.toid, HEXTORAW('00')) = o$.oid$ (+) AND
                NVL(o$.owner#, -1) = u$.user# (+) AND
                NVL(o$.type#, -1) != 10 /* bug 882543: no non-existent types */

