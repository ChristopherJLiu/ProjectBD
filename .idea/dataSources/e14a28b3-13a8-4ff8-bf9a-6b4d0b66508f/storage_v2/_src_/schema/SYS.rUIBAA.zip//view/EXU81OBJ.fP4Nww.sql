CREATE VIEW EXU81OBJ AS
  SELECT  o$."OBJ#",o$."DATAOBJ#",o$."OWNER#",o$."NAME",o$."NAMESPACE",o$."SUBNAME",o$."TYPE#",o$."CTIME",o$."MTIME",o$."STIME",o$."STATUS",o$."REMOTEOWNER",o$."LINKNAME",o$."FLAGS",o$."OID$",o$."SPARE1",o$."SPARE2",o$."SPARE3",o$."SPARE4",o$."SPARE5",o$."SPARE6"
        FROM    sys.obj$ o$, sys.user$ u$
        WHERE   BITAND(o$.flags, 16) != 16 AND
                /* Ignore recycle bin objects */
                BITAND(o$.flags, 128) != 128 AND
                o$.owner# = u$.user# AND
                u$.name NOT IN ('ORDSYS',  'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                                'LBACSYS', 'XDB',   'SI_INFORMTN_SCHEMA',
                                'DIP', 'DBSNMP', 'EXFSYS', 'WMSYS','ORACLE_OCM',
                                'ANONYMOUS', 'XS$NULL', 'APPQOSSYS')
/

