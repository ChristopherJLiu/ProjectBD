CREATE VIEW IMP9CON AS
  SELECT  c.name, o.name, u.name, cc.intcol#, cc.col#, cd.type#
        FROM    sys.obj$ o, sys.user$ u, sys.con$ c, sys.ccol$ cc,
                sys.cdef$ cd
        WHERE   o.obj# = cc.obj# AND
                c.con# = cc.con# AND
                o.obj# = cd.obj# AND
                u.user# = c.owner# AND
                cd.con# = c.con# AND
                BITAND(cd.defer, 8) = 8
/

