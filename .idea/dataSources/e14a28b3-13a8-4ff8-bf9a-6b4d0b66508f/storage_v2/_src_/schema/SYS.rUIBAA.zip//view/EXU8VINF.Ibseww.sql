CREATE VIEW EXU8VINF AS
  SELECT  o$.obj#, o$.name, v$.text, u$.name, o$.owner#, v$.audit$,
                com$.comment$, c$.name, v$.property, NVL(cd$.defer, 0),
                NVL(o$.flags, 0), NVL(vt$.oidtextlength, 0), vt$.oidtext,
                vt$.typeowner, vt$.typename, v$.textlength
        FROM    sys.obj$ o$, sys.view$ v$, sys.user$ u$, sys.cdef$ cd$,
                sys.con$ c$, sys.com$ com$, sys.typed_view$ vt$
        WHERE   v$.obj# = o$.obj# AND
                o$.owner# = u$.user# AND
                o$.obj# = cd$.obj#(+) AND
                cd$.con# = c$.con#(+) AND
                o$.obj# = com$.obj#(+) AND
                com$.col#(+) IS NULL AND
                v$.obj# = vt$.obj# (+)
/

