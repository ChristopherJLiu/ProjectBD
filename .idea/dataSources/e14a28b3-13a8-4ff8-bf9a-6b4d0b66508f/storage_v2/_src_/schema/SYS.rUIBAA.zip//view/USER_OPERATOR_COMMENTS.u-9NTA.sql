CREATE VIEW USER_OPERATOR_COMMENTS AS
  select u.name, o.name, c.comment$
from   sys.obj$ o, sys.operator$ op, sys.com$ c, sys.user$ u
where  o.obj# = op.obj# and c.obj# = op.obj# and u.user# = o.owner#
       and o.owner# = userenv('SCHEMAID')
/

