CREATE VIEW EXU81CTX AS
  SELECT  o$.name, c$.schema, c$.package, o$.obj#
        FROM    sys.exu81obj o$, sys.context$ c$
        WHERE   o$.type# = 44 AND                                 /* context */
                o$.obj# = c$.obj#
/

