CREATE VIEW DBA_SUBSCRIBED_TABLES AS
  SELECT
   st.handle, t.source_schema_name, t.source_table_name, st.view_name,
   t.change_set_name, s.subscription_name
  FROM sys.cdc_subscribed_tables$ st, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ s
  WHERE st.change_table_obj#=t.obj# AND
        s.handle = st.handle
/

