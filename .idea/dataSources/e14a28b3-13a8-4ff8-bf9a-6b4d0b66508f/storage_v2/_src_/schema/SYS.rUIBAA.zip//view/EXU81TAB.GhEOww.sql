CREATE VIEW EXU81TAB AS
  SELECT  "OBJID","DOBJID","NAME","OWNER","OWNERID","TABLESPACE","TSNO","FILENO","BLOCKNO","AUDIT$","COMMENT$","CLUSTERFLAG","MTIME","MODIFIED","TABNO","PCTFREE$","PCTUSED$","INITRANS","MAXTRANS","DEGREE","INSTANCES","CACHE","TEMPFLAGS","PROPERTY","DEFLOG","TSDEFLOG","ROID","RECPBLK","SECONDARYOBJ","ROWCNT","BLKCNT","AVGRLEN","TFLAGS","TRIGFLAG","OBJSTATUS","XDBOOL"
        FROM    sys.exu81tabs
        WHERE   secondaryobj = 0 AND
                ( NOT EXISTS (
                         SELECT  *
                         FROM    sys.col$ c$, sys.coltype$ ct$, sys.type$ t$
                         WHERE   c$.obj# = objid AND
                                 ct$.toid = t$.toid AND
                                 c$.obj# = ct$.obj# AND
                                 c$.col# = ct$.col# AND
                                 ((BITAND(t$.PROPERTIES, 8) = 8) OR
                                 (BITAND(t$.PROPERTIES, 8192) = 8192))))
/

