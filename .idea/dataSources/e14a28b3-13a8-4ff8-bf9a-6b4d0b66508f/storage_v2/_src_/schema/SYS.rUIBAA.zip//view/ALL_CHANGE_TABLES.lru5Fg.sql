CREATE VIEW ALL_CHANGE_TABLES AS
  SELECT
   s.change_table_schema, s.change_table_name, s.change_set_name,
   s.source_schema_name, s.source_table_name, s.created, s.created_scn,
   s.captured_values, s.obj#
  FROM sys.cdc_change_tables$ s
/

