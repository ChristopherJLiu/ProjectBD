CREATE VIEW DBA_SUBSCRIBED_COLUMNS AS
  SELECT
   sc.handle, t.source_schema_name, t.source_table_name, sc.column_name,
   s.subscription_name, y.source_database
  FROM sys.cdc_subscribed_columns$ sc, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ s, sys.cdc_change_sets$ x,
       sys.cdc_change_sources$ y
  WHERE sc.change_table_obj#=t.obj# AND
        s.handle = sc.handle AND
        t.change_set_name=x.set_name AND
        x.change_source_name = y.source_name
/

