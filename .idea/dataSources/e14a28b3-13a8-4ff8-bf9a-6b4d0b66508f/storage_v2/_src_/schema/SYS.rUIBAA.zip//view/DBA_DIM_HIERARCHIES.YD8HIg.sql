CREATE VIEW DBA_DIM_HIERARCHIES AS
  select u.name, o.name, h.hiername
from sys.hier$ h, sys.obj$ o, sys.user$ u
where h.dimobj# = o.obj#
  and o.owner# = u.user#
/

