CREATE VIEW EXU8ORDU AS
  SELECT  "DLEVEL","OBJ#","D_OWNER#"
        FROM    sys.exu8ord
        WHERE   d_owner# = UID
/

