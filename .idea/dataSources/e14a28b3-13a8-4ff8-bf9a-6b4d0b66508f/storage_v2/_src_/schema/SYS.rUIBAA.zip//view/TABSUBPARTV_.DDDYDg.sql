CREATE VIEW TABSUBPARTV$ AS
  select obj#, dataobj#, pobj#,
          row_number() over (partition by pobj# order by subpart#),
          flags, ts#, file#, block#, pctfree$,
          pctused$, initrans, maxtrans, analyzetime, samplesize, rowcnt,
          blkcnt, empcnt, avgspc, chncnt, avgrln, spare1, spare2, spare3,
          hiboundlen, hiboundval, subpart#
from tabsubpart$
/

