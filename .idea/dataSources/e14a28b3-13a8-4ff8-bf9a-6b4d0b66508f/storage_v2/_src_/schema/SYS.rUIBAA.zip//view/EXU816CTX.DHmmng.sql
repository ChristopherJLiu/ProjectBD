CREATE VIEW EXU816CTX AS
  SELECT  o$.name, c$.schema, c$.package, c$.flags
        FROM    sys.exu81obj o$, sys.context$ c$
        WHERE   o$.type# = 44 AND
                o$.obj# = c$.obj#
/

