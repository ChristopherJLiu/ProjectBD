CREATE VIEW EXU816TCTX AS
  SELECT  cols
        FROM    sys.tab$ t, sys.obj$ o
        WHERE   t.obj# = o.obj# AND
                o.name = 'CONTEXT$' AND
                o.type# = 2 AND
                o.owner# = 0
/

