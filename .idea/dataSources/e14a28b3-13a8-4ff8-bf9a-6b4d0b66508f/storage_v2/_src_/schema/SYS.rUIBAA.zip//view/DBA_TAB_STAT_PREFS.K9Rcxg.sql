CREATE VIEW DBA_TAB_STAT_PREFS AS
  select u.name, o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o, user$ u
where p.obj#=o.obj#
  and u.user#=o.owner#
  and o.type#=2
/

