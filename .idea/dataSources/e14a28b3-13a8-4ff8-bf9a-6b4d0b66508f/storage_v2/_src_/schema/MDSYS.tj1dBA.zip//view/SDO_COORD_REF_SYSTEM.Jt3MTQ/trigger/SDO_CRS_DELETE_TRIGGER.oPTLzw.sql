-- Cannot generate trigger SDO_CRS_DELETE_TRIGGER: the table is unknown
/

