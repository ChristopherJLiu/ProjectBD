CREATE TRIGGER "Vis3DConfig299_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Vis3DConfig299_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Vis3DConfig299_TAB', :old.sys_nc_oid$, 'C3B9F769B1FD461894E999F4EDC8BDCB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Vis3DConfig299_TAB', :old.sys_nc_oid$, 'C3B9F769B1FD461894E999F4EDC8BDCB', user ); END IF; END;
/

