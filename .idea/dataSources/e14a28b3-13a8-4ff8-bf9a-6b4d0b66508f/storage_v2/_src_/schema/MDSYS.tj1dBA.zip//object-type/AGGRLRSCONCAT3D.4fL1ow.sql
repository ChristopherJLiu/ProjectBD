CREATE type AggrLRSConcat3D AUTHID current_user as Object
(
  context mdsys.SDOAggr,
  static function odciaggregateinitialize(sctx OUT AggrLRSConcat3D) return number,
  member function odciaggregateiterate(self IN OUT AggrLRSConcat3D,
               			       geom IN mdsys.SDOAggrType) return number,
  member function odciaggregateterminate(self IN AggrLRSConcat3D,
                                           returnValue OUT mdsys.sdo_geometry,
                                          flags IN number)
                     return number,
  member function odciaggregatemerge(self   IN OUT AggrLRSConcat3D,
                    		     valueB IN  AggrLRSConcat3D) return number);
/

