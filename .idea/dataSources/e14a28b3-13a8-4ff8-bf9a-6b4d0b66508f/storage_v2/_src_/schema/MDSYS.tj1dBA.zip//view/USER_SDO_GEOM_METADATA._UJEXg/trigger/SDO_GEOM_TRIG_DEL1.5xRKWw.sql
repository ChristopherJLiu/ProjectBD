-- Cannot generate trigger SDO_GEOM_TRIG_DEL1: the table is unknown
/

