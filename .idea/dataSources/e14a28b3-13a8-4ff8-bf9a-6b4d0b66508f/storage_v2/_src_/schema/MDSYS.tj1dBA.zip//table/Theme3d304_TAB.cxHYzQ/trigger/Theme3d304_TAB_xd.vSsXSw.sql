CREATE TRIGGER "Theme3d304_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Theme3d304_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Theme3d304_TAB', :old.sys_nc_oid$, 'F4890BD0C4004C42AF305AC08EBB68C5' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Theme3d304_TAB', :old.sys_nc_oid$, 'F4890BD0C4004C42AF305AC08EBB68C5', user ); END IF; END;
/

