CREATE FUNCTION hhmaxcode(hhc IN RAW, maxlen IN NUMBER)
    RETURN RAW IS
begin
 return md.hhmaxcode(hhc, maxlen);
end;
/

