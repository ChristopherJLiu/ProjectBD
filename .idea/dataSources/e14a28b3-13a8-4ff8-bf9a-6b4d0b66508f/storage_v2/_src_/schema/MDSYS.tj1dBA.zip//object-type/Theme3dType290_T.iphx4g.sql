CREATE TYPE         "Theme3dType290_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"LOD" "LOD291_T","DefaultStyle" "Style3dType280_T","Tiling" "Tiling292_T","hidden_info" "hidden_info293_T","ExternalRepresentations" "ExternalRepresentations296_T")NOT FINAL INSTANTIABLE
/

