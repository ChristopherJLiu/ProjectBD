CREATE VIEW SDO_RELATEMASK_TABLE AS
  select sdo_mask, sdo_relation from md$relate
/

