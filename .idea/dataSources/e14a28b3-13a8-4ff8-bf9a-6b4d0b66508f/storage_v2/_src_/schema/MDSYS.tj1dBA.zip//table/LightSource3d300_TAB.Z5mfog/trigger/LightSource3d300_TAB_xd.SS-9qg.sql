CREATE TRIGGER "LightSource3d300_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "LightSource3d300_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','LightSource3d300_TAB', :old.sys_nc_oid$, '530D9FF8CDFC403EA6E231B4DDDF3D7B' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','LightSource3d300_TAB', :old.sys_nc_oid$, '530D9FF8CDFC403EA6E231B4DDDF3D7B', user ); END IF; END;
/

