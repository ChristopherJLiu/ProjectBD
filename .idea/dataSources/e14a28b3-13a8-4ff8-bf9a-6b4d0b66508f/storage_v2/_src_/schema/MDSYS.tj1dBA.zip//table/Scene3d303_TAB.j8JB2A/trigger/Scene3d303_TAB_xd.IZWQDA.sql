CREATE TRIGGER "Scene3d303_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Scene3d303_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Scene3d303_TAB', :old.sys_nc_oid$, '829062B1A38F4CE3826EDFABA140317C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Scene3d303_TAB', :old.sys_nc_oid$, '829062B1A38F4CE3826EDFABA140317C', user ); END IF; END;
/

