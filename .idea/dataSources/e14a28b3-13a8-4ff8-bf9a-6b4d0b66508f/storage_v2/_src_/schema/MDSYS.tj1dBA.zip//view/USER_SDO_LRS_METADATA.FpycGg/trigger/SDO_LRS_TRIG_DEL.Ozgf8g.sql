-- Cannot generate trigger SDO_LRS_TRIG_DEL: the table is unknown
/

