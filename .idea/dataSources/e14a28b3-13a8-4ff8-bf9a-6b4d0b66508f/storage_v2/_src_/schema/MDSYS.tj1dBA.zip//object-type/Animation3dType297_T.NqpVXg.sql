CREATE TYPE         "Animation3dType297_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","closedLoop" RAW(1),"SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3d298_COLL","DefaultStyle" "Style3dType280_T")NOT FINAL INSTANTIABLE
/

