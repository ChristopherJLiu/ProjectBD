CREATE TRIGGER "DefaultStyle284_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "DefaultStyle284_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','DefaultStyle284_TAB', :old.sys_nc_oid$, 'A463AAA66C2E4E5ABDA3C5E7880C1CF6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','DefaultStyle284_TAB', :old.sys_nc_oid$, 'A463AAA66C2E4E5ABDA3C5E7880C1CF6', user ); END IF; END;
/

