CREATE TRIGGER "ViewFrame3d302_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ViewFrame3d302_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewFrame3d302_TAB', :old.sys_nc_oid$, '70E81CA7F8F64E889B8D63A1CA12831C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewFrame3d302_TAB', :old.sys_nc_oid$, '70E81CA7F8F64E889B8D63A1CA12831C', user ); END IF; END;
/

