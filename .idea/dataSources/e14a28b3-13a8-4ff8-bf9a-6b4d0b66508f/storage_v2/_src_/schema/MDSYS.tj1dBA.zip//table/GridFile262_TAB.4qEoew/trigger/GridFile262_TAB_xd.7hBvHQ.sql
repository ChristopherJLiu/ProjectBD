CREATE TRIGGER "GridFile262_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "GridFile262_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','GridFile262_TAB', :old.sys_nc_oid$, '970C8BF7E3B54BEEBE346B82BD526EE1' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','GridFile262_TAB', :old.sys_nc_oid$, '970C8BF7E3B54BEEBE346B82BD526EE1', user ); END IF; END;
/

