-- Cannot generate trigger SDO_GEOM_TRIG_UPD1: the table is unknown
/

