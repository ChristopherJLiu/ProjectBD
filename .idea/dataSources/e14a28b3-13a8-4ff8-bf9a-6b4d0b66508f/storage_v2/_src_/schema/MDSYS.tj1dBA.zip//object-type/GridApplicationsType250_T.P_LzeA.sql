CREATE TYPE         "GridApplicationsType250_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridApplication" "GridApplication252_COLL")NOT FINAL INSTANTIABLE
/

