CREATE TYPE         "ViewFrame3dType286_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3dType287_T","DefaultStyle" "Style3dType280_T")NOT FINAL INSTANTIABLE
/

