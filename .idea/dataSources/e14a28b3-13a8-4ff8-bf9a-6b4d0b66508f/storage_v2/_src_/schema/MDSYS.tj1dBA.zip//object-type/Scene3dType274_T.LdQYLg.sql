CREATE TYPE         "Scene3dType274_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"Theme" "Theme276_COLL","ExternalTheme" "ExternalTheme279_COLL","DefaultStyle" "Style3dType280_T")NOT FINAL INSTANTIABLE
/

