CREATE TYPE         "TextureType282_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TextureBLOB" "SharedValueType281_T","TextureCoordinates" "SharedValueType281_T")NOT FINAL INSTANTIABLE
/

