CREATE TRIGGER "ForeignKey272_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ForeignKey272_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ForeignKey272_TAB', :old.sys_nc_oid$, 'F8C7103E9BB24A9C93662507857C561C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ForeignKey272_TAB', :old.sys_nc_oid$, 'F8C7103E9BB24A9C93662507857C561C', user ); END IF; END;
/

