CREATE TRIGGER "ViewPoint3d289_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ViewPoint3d289_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewPoint3d289_TAB', :old.sys_nc_oid$, '1B392E4E8FA94196805A85703243D0F1' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewPoint3d289_TAB', :old.sys_nc_oid$, '1B392E4E8FA94196805A85703243D0F1', user ); END IF; END;
/

