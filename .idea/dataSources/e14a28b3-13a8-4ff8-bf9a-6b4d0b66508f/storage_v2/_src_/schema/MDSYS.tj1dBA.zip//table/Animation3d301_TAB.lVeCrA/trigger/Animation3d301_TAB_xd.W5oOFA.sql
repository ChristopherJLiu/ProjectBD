CREATE TRIGGER "Animation3d301_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Animation3d301_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Animation3d301_TAB', :old.sys_nc_oid$, '3987B07F57D44C4BA7199892BED0117B' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Animation3d301_TAB', :old.sys_nc_oid$, '3987B07F57D44C4BA7199892BED0117B', user ); END IF; END;
/

