CREATE TYPE         "ExternalRepresentations296_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GML" "SharedValueType281_T","CityGML" "SharedValueType281_T","KML" "SharedValueType281_T","X3D" "SharedValueType281_T","BIM" "SharedValueType281_T")FINAL INSTANTIABLE
/

