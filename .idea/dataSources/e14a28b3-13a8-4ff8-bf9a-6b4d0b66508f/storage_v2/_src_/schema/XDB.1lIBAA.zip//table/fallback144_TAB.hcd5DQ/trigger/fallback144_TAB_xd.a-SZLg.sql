CREATE TRIGGER "fallback144_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "fallback144_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback144_TAB', :old.sys_nc_oid$, '3E742F1EB8364A62BA2DF42B15CDA53D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback144_TAB', :old.sys_nc_oid$, '3E742F1EB8364A62BA2DF42B15CDA53D', user ); END IF; END;
/

