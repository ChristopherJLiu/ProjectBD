CREATE TRIGGER "http-log109_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "http-log109_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','http-log109_TAB', :old.sys_nc_oid$, 'A620FA929FD94D609CE863BCD41149CD' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','http-log109_TAB', :old.sys_nc_oid$, 'A620FA929FD94D609CE863BCD41149CD', user ); END IF; END;
/

