CREATE TRIGGER "include148_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "include148_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','include148_TAB', :old.sys_nc_oid$, '219FDAECCBD64ED5A6D38537477436B6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','include148_TAB', :old.sys_nc_oid$, '219FDAECCBD64ED5A6D38537477436B6', user ); END IF; END;
/

