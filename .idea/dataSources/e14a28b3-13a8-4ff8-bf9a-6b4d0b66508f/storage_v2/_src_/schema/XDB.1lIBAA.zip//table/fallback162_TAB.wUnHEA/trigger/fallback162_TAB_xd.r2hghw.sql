CREATE TRIGGER "fallback162_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "fallback162_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback162_TAB', :old.sys_nc_oid$, 'E165651AAD5240DC97FA579B09F5A91A' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback162_TAB', :old.sys_nc_oid$, 'E165651AAD5240DC97FA579B09F5A91A', user ); END IF; END;
/

