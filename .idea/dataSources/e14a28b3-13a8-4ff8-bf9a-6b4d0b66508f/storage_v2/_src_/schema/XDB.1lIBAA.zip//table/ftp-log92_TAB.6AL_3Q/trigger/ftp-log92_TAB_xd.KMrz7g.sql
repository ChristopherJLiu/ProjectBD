CREATE TRIGGER "ftp-log92_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ftp-log92_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','ftp-log92_TAB', :old.sys_nc_oid$, 'FE1889A2937F4828B6DC2A6A480D869A' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','ftp-log92_TAB', :old.sys_nc_oid$, 'FE1889A2937F4828B6DC2A6A480D869A', user ); END IF; END;
/

