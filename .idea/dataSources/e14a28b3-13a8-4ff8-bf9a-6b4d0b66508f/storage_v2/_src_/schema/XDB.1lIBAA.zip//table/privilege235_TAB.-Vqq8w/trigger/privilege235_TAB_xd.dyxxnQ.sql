CREATE TRIGGER "privilege235_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "privilege235_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','privilege235_TAB', :old.sys_nc_oid$, '1EEFAB108D594CDC8FE3DD34182AD894' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','privilege235_TAB', :old.sys_nc_oid$, '1EEFAB108D594CDC8FE3DD34182AD894', user ); END IF; END;
/

