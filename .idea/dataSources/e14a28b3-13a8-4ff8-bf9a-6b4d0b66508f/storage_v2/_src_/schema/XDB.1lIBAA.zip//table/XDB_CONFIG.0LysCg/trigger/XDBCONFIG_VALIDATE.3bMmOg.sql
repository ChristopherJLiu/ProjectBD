CREATE TRIGGER XDBCONFIG_VALIDATE
  BEFORE INSERT OR UPDATE
  ON XDB$CONFIG
  FOR EACH ROW
  declare
  xdoc xmltype;
begin
  xdoc := :new.sys_nc_rowinfo$;
  xmltype.schemaValidate(xdoc);
end;
/

