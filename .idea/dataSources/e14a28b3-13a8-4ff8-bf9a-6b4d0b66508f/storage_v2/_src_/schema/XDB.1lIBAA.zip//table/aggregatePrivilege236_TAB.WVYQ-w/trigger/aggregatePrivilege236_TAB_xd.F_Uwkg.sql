CREATE TRIGGER "aggregatePrivilege236_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "aggregatePrivilege236_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','aggregatePrivilege236_TAB', :old.sys_nc_oid$, '50090CDEF9424483B843664C027F4586' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','aggregatePrivilege236_TAB', :old.sys_nc_oid$, '50090CDEF9424483B843664C027F4586', user ); END IF; END;
/

