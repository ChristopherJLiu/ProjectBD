CREATE TRIGGER "fallback163_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "fallback163_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback163_TAB', :old.sys_nc_oid$, 'AF1DA3F8D21D49F4A83000EA28D07E38' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback163_TAB', :old.sys_nc_oid$, 'AF1DA3F8D21D49F4A83000EA28D07E38', user ); END IF; END;
/

