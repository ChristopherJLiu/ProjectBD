CREATE TRIGGER "title231_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "title231_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','title231_TAB', :old.sys_nc_oid$, 'B780F043A59F4F6AA88A199F30AF379C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','title231_TAB', :old.sys_nc_oid$, 'B780F043A59F4F6AA88A199F30AF379C', user ); END IF; END;
/

