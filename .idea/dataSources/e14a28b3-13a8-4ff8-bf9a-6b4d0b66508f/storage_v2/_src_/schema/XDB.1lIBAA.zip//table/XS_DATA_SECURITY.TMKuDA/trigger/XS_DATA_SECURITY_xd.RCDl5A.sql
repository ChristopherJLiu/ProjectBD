CREATE TRIGGER "XS$DATA_SECURITY$xd"
  AFTER UPDATE OR DELETE
  ON XS$DATA_SECURITY
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XS$DATA_SECURITY', :old.sys_nc_oid$, '58A1259893C74686AD4C42FE8730565A' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XS$DATA_SECURITY', :old.sys_nc_oid$, '58A1259893C74686AD4C42FE8730565A', user ); END IF; END;
/

