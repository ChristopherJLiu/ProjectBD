CREATE TRIGGER "XDB$ACL$xd"
  AFTER UPDATE OR DELETE
  ON XDB$ACL
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$ACL', :old.sys_nc_oid$, 'EB2572AE803849DBA6C0B1D17E088584' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$ACL', :old.sys_nc_oid$, 'EB2572AE803849DBA6C0B1D17E088584', user ); END IF; END;
/

