CREATE TRIGGER "fallback143_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "fallback143_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback143_TAB', :old.sys_nc_oid$, '3D481629DFA34230BEF5DB9CC0DF1E08' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback143_TAB', :old.sys_nc_oid$, '3D481629DFA34230BEF5DB9CC0DF1E08', user ); END IF; END;
/

