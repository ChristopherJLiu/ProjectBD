CREATE TRIGGER "description232_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "description232_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','description232_TAB', :old.sys_nc_oid$, '9C9F0E76D21B47BF959F5B05EA1E16D2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','description232_TAB', :old.sys_nc_oid$, '9C9F0E76D21B47BF959F5B05EA1E16D2', user ); END IF; END;
/

