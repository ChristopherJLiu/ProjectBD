CREATE TYPE       "xdb-log82_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","xdb-log-entry" "xdb-log-entry83_COLL")FINAL INSTANTIABLE
/

