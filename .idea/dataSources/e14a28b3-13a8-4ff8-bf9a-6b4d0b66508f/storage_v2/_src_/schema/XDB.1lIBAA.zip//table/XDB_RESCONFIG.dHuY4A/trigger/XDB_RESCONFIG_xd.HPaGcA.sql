CREATE TRIGGER "XDB$RESCONFIG$xd"
  AFTER UPDATE OR DELETE
  ON XDB$RESCONFIG
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '8AF791F0AAFF4771AB33262B3219A5D8' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '8AF791F0AAFF4771AB33262B3219A5D8', user ); END IF; END;
/

