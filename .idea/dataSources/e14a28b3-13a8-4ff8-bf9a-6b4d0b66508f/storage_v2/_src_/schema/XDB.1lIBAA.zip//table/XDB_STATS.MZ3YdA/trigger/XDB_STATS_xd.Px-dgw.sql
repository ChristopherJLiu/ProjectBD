CREATE TRIGGER "XDB$STATS$xd"
  AFTER UPDATE OR DELETE
  ON XDB$STATS
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, '3EF8ACDD5A05439FB1EF6D6968E341F4' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, '3EF8ACDD5A05439FB1EF6D6968E341F4', user ); END IF; END;
/

