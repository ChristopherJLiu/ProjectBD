CREATE TRIGGER "XDB$CONFIG$xd"
  AFTER UPDATE OR DELETE
  ON XDB$CONFIG
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$CONFIG', :old.sys_nc_oid$, '4EFCAF3653F64EB9A1D26D3D1817719D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$CONFIG', :old.sys_nc_oid$, '4EFCAF3653F64EB9A1D26D3D1817719D', user ); END IF; END;
/

