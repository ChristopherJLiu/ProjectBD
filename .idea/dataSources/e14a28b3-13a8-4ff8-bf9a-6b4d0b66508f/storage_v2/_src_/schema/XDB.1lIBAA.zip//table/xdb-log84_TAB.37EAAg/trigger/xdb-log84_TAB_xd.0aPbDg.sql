CREATE TRIGGER "xdb-log84_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "xdb-log84_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','xdb-log84_TAB', :old.sys_nc_oid$, '46AEFAAFC0A64BD89236BC76C8426D69' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','xdb-log84_TAB', :old.sys_nc_oid$, '46AEFAAFC0A64BD89236BC76C8426D69', user ); END IF; END;
/

