CREATE TRIGGER "XS$ROLESETS$xd"
  AFTER UPDATE OR DELETE
  ON XS$ROLESETS
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XS$ROLESETS', :old.sys_nc_oid$, 'F6C5446391124584B64E2F8B570FF4F5' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XS$ROLESETS', :old.sys_nc_oid$, 'F6C5446391124584B64E2F8B570FF4F5', user ); END IF; END;
/

