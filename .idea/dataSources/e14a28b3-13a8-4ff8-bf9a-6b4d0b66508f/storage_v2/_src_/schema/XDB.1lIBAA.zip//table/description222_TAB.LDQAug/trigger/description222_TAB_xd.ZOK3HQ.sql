CREATE TRIGGER "description222_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "description222_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','description222_TAB', :old.sys_nc_oid$, '7E3E003E22324A5E9D40B6E155187B78' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','description222_TAB', :old.sys_nc_oid$, '7E3E003E22324A5E9D40B6E155187B78', user ); END IF; END;
/

