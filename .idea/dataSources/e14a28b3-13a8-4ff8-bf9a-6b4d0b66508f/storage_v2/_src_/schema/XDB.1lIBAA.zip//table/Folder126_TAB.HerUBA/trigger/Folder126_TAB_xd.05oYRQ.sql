CREATE TRIGGER "Folder126_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Folder126_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','Folder126_TAB', :old.sys_nc_oid$, 'BA650FC6A68440F8BEE2ED10B26A8521' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','Folder126_TAB', :old.sys_nc_oid$, 'BA650FC6A68440F8BEE2ED10B26A8521', user ); END IF; END;
/

