CREATE TRIGGER "title221_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "title221_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','title221_TAB', :old.sys_nc_oid$, '59668448682F4BBA9F89C6D471DC27DE' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','title221_TAB', :old.sys_nc_oid$, '59668448682F4BBA9F89C6D471DC27DE', user ); END IF; END;
/

