CREATE TRIGGER "include167_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "include167_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','include167_TAB', :old.sys_nc_oid$, '7F5F3A12EAC9480E88E400FE72D607A5' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','include167_TAB', :old.sys_nc_oid$, '7F5F3A12EAC9480E88E400FE72D607A5', user ); END IF; END;
/

