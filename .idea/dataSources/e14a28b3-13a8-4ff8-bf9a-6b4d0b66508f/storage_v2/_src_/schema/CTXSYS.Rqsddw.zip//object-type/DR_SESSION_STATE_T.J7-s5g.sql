CREATE type dr$session_state_t as object(
  logfile   varchar2(2000),
  events    number,
  traces    number
);
/

