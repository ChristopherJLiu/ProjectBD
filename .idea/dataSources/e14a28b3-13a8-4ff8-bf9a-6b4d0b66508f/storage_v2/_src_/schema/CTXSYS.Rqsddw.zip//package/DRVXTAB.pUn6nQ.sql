CREATE package drvxtab authid current_user as

  DEFAULT_SEPARATOR       constant varchar2(1) := '$';
  TMP1_SEPARATOR          constant varchar2(1) := 'M';
  TMP2_SEPARATOR          constant varchar2(1) := 'N';

PROCEDURE part_events_off;
PROCEDURE part_events_on;

/* ====================================================================== */
/* ====================================================================== */
/*                             CONTEXT                                    */
/* ====================================================================== */
/* ====================================================================== */

/*------------------------- create_a_table --------------------------------*/
PROCEDURE create_a_table(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*------------------------- create_f_table --------------------------------*/
PROCEDURE create_f_table(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*-------------------------- create_s_table ------------------------------*/
PROCEDURE create_s_table(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  sep       in varchar2,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE
);

/*---------------------- part_create_s_tables -----------------------------*/
PROCEDURE part_create_s_tables(
  idx  in dr_def.idx_rec
);

/*----------------------- create_index_tables -----------------------------*/

PROCEDURE create_index_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  temp      in boolean default FALSE,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE
);

/*--------------------------- create_g_table ---------------------------*/
procedure create_g_table(
  idx dr_def.idx_rec
);

/*--------------------------- drop_g_table --------------------------------*/
procedure drop_g_table(
  idx dr_def.idx_rec
);

/*--------------------------- add_offsets_column --------------------------*/
procedure add_offsets_column(
  idx dr_def.idx_rec
);

-- 8323978: Removed create_index_triggers

/*----------------------- create_index_indexes  ---------------------------*/

PROCEDURE create_index_indexes(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  temp      in boolean default FALSE,
  part      in boolean default FALSE
);

/*----------------------- drop_index_tables  ---------------------------*/

PROCEDURE drop_index_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  has_p     in boolean default null,
  part_id   in number default null,
  temp      in boolean default FALSE,
  isAlter   in boolean default FALSE
);

/*----------------------- drop_FA_tables  -------------------------------*/

PROCEDURE drop_FA_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- trunc_index_tables  ---------------------------*/

PROCEDURE trunc_index_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null
);

/*----------------------- rename_index_tables  ---------------------------*/

PROCEDURE rename_index_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  new_name  in varchar2,
  has_idx   in boolean,
  part_id   in number default null
);

/*----------------------- exchange_index_tables  --------------------------*/

PROCEDURE exchange_index_tables(
  idxp_owner in varchar2,
  idxp_name  in varchar2,
  idxp_id    in number,
  idxp_pid   in number,
  idxn_owner in varchar2,
  idxn_name  in varchar2,
  idxn_id    in number
);

/*-------------------------- get_create_sql -------------------------------*/

FUNCTION get_create_sql(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  which     in varchar2,
  sto       in out nocopy dr_def.vc500_tab,
  sep       in varchar2 default DEFAULT_SEPARATOR,
  x_part    in boolean default FALSE
) RETURN VARCHAR2;

/*-------------------------- get_object_name ------------------------------*/

FUNCTION get_object_name(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  which     in varchar2,
  sep       in varchar2 default DEFAULT_SEPARATOR
) RETURN VARCHAR2;

/*-------------------------- get_object_prefix ------------------------------*/

FUNCTION get_object_prefix(
  idx_owner in varchar2,
  idx_name  in varchar2,
  part_id   in number default null,
  sep       in varchar2 default DEFAULT_SEPARATOR
) RETURN VARCHAR2;

/*---------------------- swap_index_temp_tables -----------------------*/
PROCEDURE swap_index_temp_tables (
  idx_owner  in varchar2,
  idx_name   in varchar2,
  idxid      in number,
  idx_pid    in number,
  temp_owner in varchar2,
  temp_name  in varchar2,
  shadow_idxid in number default NULL,
  shadow_ixpid in number default NULL
);

/*----------------------- populate_ptable -----------------------------------*/

PROCEDURE populate_ptable(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default NULL,
  shadow    in boolean default FALSE,
  ctxcat    in boolean default FALSE
);

/*----------------------- AlterDollarITType --------------------------------*/

PROCEDURE AlterDollarITType(
  idx in dr_def.idx_rec
);

PROCEDURE AdjustTType(
  idx    in dr_def.idx_rec,
  shad_i in varchar2
);

end drvxtab;
/

