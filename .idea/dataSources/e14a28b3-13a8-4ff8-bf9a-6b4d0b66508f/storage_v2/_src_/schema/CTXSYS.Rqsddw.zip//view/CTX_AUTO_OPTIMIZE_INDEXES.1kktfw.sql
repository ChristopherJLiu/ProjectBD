CREATE VIEW CTX_AUTO_OPTIMIZE_INDEXES AS
  select
  o.aoi_ownname aoi_index_owner,
  o.aoi_idxname aoi_index_name,
  o.aoi_partname aoi_partition_name
  from dr$autoopt o
/

