CREATE package drimlx as

/*-------------------- add_sub_lexer ---------------------------*/

PROCEDURE add_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2,
  sub_lexer      in   varchar2,
  alt_value      in   varchar2 default NULL,
  language_dependent in boolean default TRUE
);

/*-------------------- remove_sub_lexer ---------------------------*/

PROCEDURE remove_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2
);

/*----------------------- copy_multi_lexer -------------------------------*/
procedure copy_multi_lexer(
  p_idx_id in  number,
  p_pref   in  dr_def.pref_rec,
  p_rcount out number
);

/*----------------------- GetIndexMultiLexer -----------------------------*/
procedure GetIndexMultiLexer(
  p_idx_id in  number,
  o_slx in out nocopy dr_def.slx_tab
);

/*-------------------------- IndexAddSLX  -------------------------------*/
procedure IndexAddSLX(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  sub_lexer in varchar2,
  language  in varchar2,
  alt_value in varchar2,
  language_dependent in boolean default TRUE,
  add_ML_tokens out boolean,
  update_slx    in boolean
);

procedure IndexRemoveSLX(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  sub_lexer in varchar2,
  rem_ML_tokens out boolean,
  update_slx    in boolean
);

procedure IndexUpdateSLX(
  ia             in sys.ODCIIndexInfo,
  idx            in dr_def.idx_rec,
  old_slx_symb   in varchar2,
  new_slx_pref   in varchar2
);

procedure GetSLXAltAbbr(
  idx_id    in number,
  sub_lexer in varchar2,
  language  in out varchar2,
  abbr      in out varchar2,
  alt       in out varchar2
);

/*-------------------- upd_sub_lexer ---------------------------*/
/* update a sub lexer in a multi-lexer preference */

PROCEDURE upd_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2,
  sub_lexer      in   varchar2
);

end drimlx;
/

