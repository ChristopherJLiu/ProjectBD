CREATE VIEW CTX_USER_THESAURI AS
  select ths_name
  from dr$ths
 where ths_owner# = userenv('SCHEMAID')
/

