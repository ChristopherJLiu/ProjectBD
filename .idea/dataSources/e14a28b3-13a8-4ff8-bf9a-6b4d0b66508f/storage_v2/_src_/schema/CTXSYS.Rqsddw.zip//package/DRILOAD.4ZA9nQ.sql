CREATE package driload as

/*---------------------------- resolve_sqe --------------------------------*/
/*
  NAME
    resolve_sqe

  NOTES
    TODO: move this to a more appropriate place
*/
FUNCTION resolve_sqe( p_idx_id in number, p_sqe_name in varchar2)
return clob;

end driload;
/

