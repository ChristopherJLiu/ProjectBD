CREATE TRIGGER WWV_FLOW_SESSIONS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_SESSIONS$
  FOR EACH ROW
  begin
    --
    -- note: new.id is typically never null on insert
    --
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    --
    --
    --
    if inserting then
        if :new.created_by is null then
            :new.created_by := user;
        end if;
        wwv_flow_security.g_crypto_salt := wwv_flow_security.crypto_randombytes(p_numbytes => 32);
        if :new.session_id_hashed is null then
            :new.session_id_hashed := wwv_flow_security.hash_session_id;
            begin
                :new.ip_address := rawtohex(wwv_flow_security.g_crypto_salt);
            exception when others then
                :new.ip_address := null;
            end;
        end if;
        :new.created_on := sysdate;
        :new.last_changed := sysdate;
        if :new.remote_addr is null then
           :new.remote_addr := wwv_flow.g_remote_addr;
        end if;
    end if;

    :new.session_time_zone := trim(:new.session_time_zone);

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

