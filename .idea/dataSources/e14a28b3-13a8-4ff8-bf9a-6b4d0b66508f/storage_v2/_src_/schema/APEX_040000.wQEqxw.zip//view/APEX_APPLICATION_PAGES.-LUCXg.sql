CREATE VIEW APEX_APPLICATION_PAGES AS
  select
    w.short_name                          workspace,
    p.flow_id                             application_id,
    f.name                                application_name,
    --
    p.id                                  page_id,
    p.name                                page_name,
    p.STEP_TITLE                          page_title,
    p.media_type                          media_type,
    p.TAB_SET                             tab_set,
    p.ALIAS                               page_alias,
    decode(substr(p.PAGE_COMPONENT_MAP,1,2),
         '01','Tabular Form',
         '02','Form',
         '03','Report',
         '04','Chart',
         '05','Web Service',
         '06','Navigation Page',
         '07','Tree',
         '08','Calendar',
         '09','URL',
         '10','Dynamic HTML',
         '11','Static HTML',
         '12','Login',
         '13','Home',
         '14','Page Zero',
         '15','Empty Page',
         '16','Dynamic Form',
         '17','Wizard Form',
         'Unknown')                       page_function,
    decode(
      p.ALLOW_DUPLICATE_SUBMISSIONS,
      'N','No','Y','Yes',null,'Yes',
      p.ALLOW_DUPLICATE_SUBMISSIONS)      allow_duplicate_submissions,
    --
    decode(INCLUDE_APEX_CSS_JS_YN,null,'Yes','Y','Yes','N','No','Unknown') INCLUDE_APEX_CSS_JS_YN,
    --
    decode(p.FIRST_ITEM,
      'AUTO_FIRST_ITEM','First Item on Page',
      'NO_FIRST_ITEM','Do not focus cursor',
      p.FIRST_ITEM)                       focus_cursor,
    p.WELCOME_TEXT                        Header_Text,
    p.BOX_WELCOME_TEXT                    Body_Header,
    --p.BOX_FOOTER_TEXT                     Body_footer,
    p.FOOTER_TEXT                         Footer_Text,
    p.HELP_TEXT                           help_text,
    (select name
     from wwv_flow_templates
     where id = p.STEP_TEMPLATE)          page_template,
     --
    decode(substr(p.REQUIRED_ROLE,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(p.REQUIRED_ROLE,'!')
     and    flow_id = f.id),
     p.REQUIRED_ROLE)                     authorization_scheme,
    p.required_role                       authorization_scheme_id,
     --
    (select case when p.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(p.REQUIRED_PATCH))         build_option,
    p.HTML_PAGE_HEADER                    page_html_header,
    p.HTML_PAGE_ONLOAD                    page_html_onload,
    p.javascript_code,
    p.javascript_code_onload,
    --sec
    decode(p.PAGE_IS_PUBLIC_Y_N,
      'N','Yes','Y','No','Yes')            page_requires_Authentication,
    decode(nvl(p.PROTECTION_LEVEL,'N'),
       'N','Unrestricted',
       'C','Arguments Must Have Checksum',
       'U','No Arguments Allowed',
       'D','No URL Access',
       p.PROTECTION_LEVEL )               page_access_protection,
    --
    (select count(*) from wwv_flow_page_plugs where flow_id = f.id and page_id = p.id) regions,
    (select count(*) from wwv_flow_step_items ii where flow_id = f.id and flow_step_id = p.id and nvl(ii.display_as,'x') != 'BUTTON') items,
    (select count(*) from wwv_flow_step_buttons where flow_id = f.id and flow_step_id = p.id) +
    (select count(*) from wwv_flow_step_items ii where flow_id = f.id and flow_step_id = p.id and nvl(ii.display_as,'x') = 'BUTTON') buttons,
    (select count(*) from wwv_flow_step_computations where flow_id = f.id and flow_step_id = p.id) computations,
    (select count(*) from wwv_flow_step_validations where flow_id = f.id and flow_step_id = p.id) validations,
    (select count(*) from wwv_flow_step_processing where flow_id = f.id and flow_step_id = p.id) processes,
    (select count(*) from wwv_flow_step_branches where flow_id = f.id and flow_step_id = p.id) branches,
    (select count(*) from wwv_flow_region_report_column where flow_id = f.id and region_id in (select id from wwv_flow_page_plugs where flow_id = f.id and page_id = p.id)) report_columns,
    --
    (select 	GROUP_NAME
     from     wwv_flow_page_groups
     where    id = p.group_id and
              flow_id = p.flow_id)        page_group,
    p.group_id                            page_group_id,
    --
    ON_DUP_SUBMISSION_GOTO_URL            ,
    ERROR_NOTIFICATION_TEXT               ,
    decode(autocomplete_on_off,null,'On','ON','On','OFF','Off') form_autocomplete,
    decode(CACHE_PAGE_YN,null,'No','N','No','Y','Yes',cache_page_yn) cached,
    CACHE_TIMEOUT_SECONDS                 cache_timeout_seconds,
    decode(CACHE_BY_USER_YN,null,'No','N','No','Y','Yes',cache_by_user_yn) cached_by_user,
    CACHE_WHEN_CONDITION_TYPE             cache_condition_type,
    CACHE_WHEN_CONDITION_E1               cache_condition_exp_1,
    CACHE_WHEN_CONDITION_E2               cache_condition_exp_2,
    page_comment                          page_comment,
    (select count(*) from WWV_FLOW_PAGE_PLUGS where flow_id = f.id and page_id = p.id and PLUG_CACHING in ('CACHED','CACHED_BY_USER'))  cached_regions,
    --
    p.created_by,
    p.created_on,
    p.LAST_UPDATED_BY                     last_updated_by,
    p.LAST_UPDATED_ON                     last_updated_on,
    --
    lpad(p.id,5,'00000')
    ||p.step_title||
    ',tabset='||p.tab_set
    ||' help='||dbms_lob.getlength(p.HELP_TEXT)||
    decode(p.BOX_WELCOME_TEXT,null,null,'bodyhead='||length(p.BOX_WELCOME_TEXT))||
    decode(p.ALIAS,null,null,' alias='||p.ALIAS)||
    (select name from wwv_flow_templates where id = p.STEP_TEMPLATE)||
    --mh bug
    --nvl((select name from wwv_flow_security_schemes where to_char(id) = ltrim(p.REQUIRED_ROLE,'!') and flow_id = f.id),p.REQUIRED_ROLE)||
    nvl((select name from wwv_flow_security_schemes where to_char(id) = ltrim(p.REQUIRED_ROLE,'!') and flow_id = f.id),
    decode(substr(p.REQUIRED_ROLE,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(p.REQUIRED_ROLE,'!')
     and    flow_id = f.id),
     p.REQUIRED_ROLE)
    )||
    --
    (select PATCH_NAME from wwv_flow_patches where id =abs(p.REQUIRED_PATCH))||
    decode(p.FIRST_ITEM,'AUTO_FIRST_ITEM','First Item on Page','NO_FIRST_ITEM','Do not focus cursor',p.FIRST_ITEM)||
    decode(p.WELCOME_TEXT,null,null,'head='||length(p.WELCOME_TEXT))||
    decode(p.FOOTER_TEXT,null,null,',foot='||length(FOOTER_TEXT))||
    ',PgAuth='||decode(p.PAGE_IS_PUBLIC_Y_N,'N','Yes','Y','No','Yes')||
    ','||decode(nvl(p.PROTECTION_LEVEL,'N'),
       'N','Unrestricted',
       'C','Arguments Must Have Checksum',
       'U','No Arguments Allowed',
       'D','No URL Access',
       p.PROTECTION_LEVEL )||
     ',onload='||length(p.HTML_PAGE_ONLOAD)||
     ',hh='||nvl(length(p.HTML_PAGE_HEADER),0)
     component_signature
from wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_company_schemas s,
     wwv_flow_companies w,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

