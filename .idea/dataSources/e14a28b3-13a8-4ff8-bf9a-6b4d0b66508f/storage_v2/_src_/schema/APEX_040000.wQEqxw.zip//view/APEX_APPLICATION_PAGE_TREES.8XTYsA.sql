CREATE VIEW APEX_APPLICATION_PAGE_TREES AS
  select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    p.id                             page_id,
    p.name                           page_name,
    t.region_id                      region_id,
    (select plug_name
     from wwv_flow_page_plugs
     where id = t.region_id)         region_name,
    --
    t.id                             tree_id,
    t.TREE_QUERY                     tree_query,
    t.TREE_SOURCE                    tree_source,
    t.TREE_TEMPLATE                  tree_template,
    t.TREE_CLICK_ACTION              tree_click_action,
    t.TREE_START_VALUE               tree_start_value,
    t.TREE_START_ITEM                tree_start_item,
    t.TREE_SELECTED_NODE             tree_selected_node,
    t.SHOW_HINTS                     show_hints,
    t.TREE_HINT_TEXT                 tree_hint_text,
    t.TREE_HAS_FOCUS                 tree_has_focus,
    t.TREE_BUTTON_OPTION             tree_button_option,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    --
    t.TREE_COMMENT                   component_comment,
    --
    p.NAME
    ||' t='||t.TREE_SOURCE
    ||substr(t.TREE_QUERY,1,50)||length(t.tree_query)
    ||' hints='||t.SHOW_HINTS||':'||t.TREE_HINT_TEXT
    ||' links='||t.TREE_CLICK_ACTION
    ||' start='||t.TREE_START_VALUE||':'||t.TREE_START_ITEM
    ||' attributes='||t.TREE_BUTTON_OPTION||':'||t.TREE_HAS_FOCUS||':'||t.TREE_TEMPLATE
    component_signature
from wwv_flow_tree_regions t,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      f.id = t.flow_id and
      p.id = t.page_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

