CREATE VIEW APEX_APPLICATION_CACHING AS
  select
    w.short_name                                        workspace,
    f.ID                                                application_id,
    f.NAME                                              application_name,
    decode(c.region_id,null,c.PAGE_ID,
    (select page_id from wwv_flow_page_plugs
     where id = c.region_id and flow_id = c.flow_id))   page_id,
    (select name
     from wwv_flow_steps
     where id in
     decode(c.region_id,null,c.PAGE_ID,
    (select page_id from wwv_flow_page_plugs
     where id = c.region_id and flow_id = c.flow_id))
      and  flow_id = f.id)                              page_name,
    decode(decode(chart_region_id,null,
    'X','Chart Region Cache'),'X',
    decode(region_id,null,'Page Cache','Region Cache')) cache_type,
    c.LANGUAGE                                          language,
    c.USER_NAME                                         caching_user,
    dbms_lob.getlength(c.PAGE_TEXT)                     cache_size,
    decode(region_id,null,null,
    (select plug_name
     from wwv_flow_page_plugs
     where id = c.region_id and flow_id = f.id))        region_name,
    c.CACHED_ON                                         cached_on,
    decode(region_id,null,
    (select cache_timeout_seconds
     from wwv_flow_steps
     where flow_id = f.id and id = c.page_id),
    (select PLUG_CACHING_MAX_AGE_IN_SEC
     from wwv_flow_page_plugs
     where id = c.region_id))                           cached_for_seconds,
    --
    round((sysdate - c.cached_on) * 3600 * 24,0)        age_in_seconds,
    --
    decode(region_id,null,
    (select cache_timeout_seconds -
             round((sysdate - c.cached_on)
             * 3600 * 24,0) a
     from wwv_flow_steps
     where flow_id = f.id and id = c.page_id),
    (select PLUG_CACHING_MAX_AGE_IN_SEC -
            round((sysdate - c.cached_on)
            * 3600 * 24,0) a
     from wwv_flow_page_plugs
     where id = c.region_id))                           timeout_in_seconds,
    c.REGION_ID                                         region_id,
    c.SECURITY_GROUP_ID                                 workspace_id
from
     wwv_flow_page_cache c,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      c.flow_id = f.id and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.security_group_id = s.SECURITY_GROUP_ID and
      s.schema = f.owner and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

