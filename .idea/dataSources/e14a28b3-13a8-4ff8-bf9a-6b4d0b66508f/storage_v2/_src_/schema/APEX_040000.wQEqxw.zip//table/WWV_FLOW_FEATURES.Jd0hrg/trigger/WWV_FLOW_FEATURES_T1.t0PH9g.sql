CREATE TRIGGER WWV_FLOW_FEATURES_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_FEATURES
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.security_group_id is null then
        :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    if inserting and :new.created_by is null then
       :new.created_by := nvl(wwv_flow.g_user,USER);
    end if;
    if inserting and :new.created_on is null then
       :new.created_on := sysdate;
    end if;
    if inserting and :new.updated_by is null then
       :new.updated_by :=nvl(wwv_flow.g_user,user);
    end if;
    if inserting and :new.updated_on is null then
       :new.updated_on := sysdate;
    end if;
    if inserting or updating then
       :new.updated_by := nvl(wwv_flow.g_user,user);
       :new.updated_on := sysdate;
    end if;

    :new.feature_owner := trim(lower(:new.feature_owner));
    :new.feature_contributor := trim(lower(:new.feature_contributor));
    :new.globalization_assignee := trim(lower(:new.globalization_assignee));
    :new.user_interface_assignee := trim(lower(:new.user_interface_assignee));
    :new.testing_assignee := trim(lower(:new.testing_assignee));
    :new.security_assignee := trim(lower(:new.security_assignee));
    :new.accessibility_assignee := trim(lower(:new.accessibility_assignee));


    if updating then

    if nvl(:old.FEATURE_NAME,'1') != nvl(:new.FEATURE_NAME,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_NAME','VARCHAR2',:old.FEATURE_NAME,:new.FEATURE_NAME);
    end if;
    if nvl(:old.FEATURE_OWNER,'1') != nvl(:new.FEATURE_OWNER,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_OWNER','VARCHAR2',:old.FEATURE_OWNER,:new.FEATURE_OWNER);
    end if;
    if nvl(:old.FEATURE_CONTRIBUTOR,'1') != nvl(:new.FEATURE_CONTRIBUTOR,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_CONTRIBUTOR','VARCHAR2',:old.FEATURE_CONTRIBUTOR,:new.FEATURE_CONTRIBUTOR);
    end if;
    --
    if nvl(:old.ESTIMATED_EFFORT_IN_HOURS,'1') != nvl(:new.ESTIMATED_EFFORT_IN_HOURS,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'ESTIMATED_EFFORT_IN_HOURS','NUMBER',:old.ESTIMATED_EFFORT_IN_HOURS,:new.ESTIMATED_EFFORT_IN_HOURS);
    end if;
    if nvl(:old.MODULE,'1') != nvl(:new.MODULE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'MODULE','VARCHAR2',:old.MODULE,:new.MODULE);
    end if;
    --
    if nvl(:old.DOC_STATUS,0) != nvl(:new.DOC_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'DOC_STATUS','NUMBER',:old.DOC_STATUS,:new.DOC_STATUS);
    end if;
    if nvl(:old.DOC_WRITER,'1') != nvl(:new.DOC_WRITER,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'DOC_WRITER','VARCHAR2',:old.DOC_WRITER,:new.DOC_WRITER);
    end if;
    --
    if nvl(:old.JUSTIFICATION,'1') != nvl(:new.JUSTIFICATION,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'JUSTIFICATION','VARCHAR2',:old.JUSTIFICATION,:new.JUSTIFICATION);
    end if;
    if nvl(:old.FEATURE_TAGS,'1') != nvl(:new.FEATURE_TAGS,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_TAGS','VARCHAR2',:old.FEATURE_TAGS,:new.FEATURE_TAGS);
    end if;
    --
    --
    if nvl(:old.USER_INTERFACE_IMPACT,'1') != nvl(:new.USER_INTERFACE_IMPACT,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'USER_INTERFACE_IMPACT','VARCHAR2',:old.USER_INTERFACE_IMPACT,:new.USER_INTERFACE_IMPACT);
    end if;
    if nvl(:old.USER_INTERFACE_ASSIGNEE,'1') != nvl(:new.USER_INTERFACE_ASSIGNEE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'USER_INTERFACE_ASSIGNEE','VARCHAR2',:old.USER_INTERFACE_ASSIGNEE,:new.USER_INTERFACE_ASSIGNEE);
    end if;
    if nvl(:old.USER_INTERFACE_STATUS,0) != nvl(:new.USER_INTERFACE_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'USER_INTERFACE_STATUS','NUMBER',:old.USER_INTERFACE_STATUS,:new.USER_INTERFACE_STATUS);
    end if;
    --
    --
    if nvl(:old.GLOBALIZATION_IMPACT,'1') != nvl(:new.GLOBALIZATION_IMPACT,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'GLOBALIZATION_IMPACT','VARCHAR2',:old.GLOBALIZATION_IMPACT,:new.GLOBALIZATION_IMPACT);
    end if;
    if nvl(:old.GLOBALIZATION_ASSIGNEE,'1') != nvl(:new.GLOBALIZATION_ASSIGNEE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'GLOBALIZATION_ASSIGNEE','VARCHAR2',:old.GLOBALIZATION_ASSIGNEE,:new.GLOBALIZATION_ASSIGNEE);
    end if;
    if nvl(:old.GLOBALIZATION_STATUS,0) != nvl(:new.GLOBALIZATION_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'GLOBALIZATION_STATUS','NUMBER',:old.GLOBALIZATION_STATUS,:new.GLOBALIZATION_STATUS);
    end if;
    --
    if nvl(:old.TESTING_IMPACT,'1') != nvl(:new.TESTING_IMPACT,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'TESTING_IMPACT','VARCHAR2',:old.TESTING_IMPACT,:new.TESTING_IMPACT);
    end if;
    if nvl(:old.TESTING_ASSIGNEE,'1') != nvl(:new.TESTING_ASSIGNEE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'TESTING_ASSIGNEE','VARCHAR2',:old.TESTING_ASSIGNEE,:new.TESTING_ASSIGNEE);
    end if;
    if nvl(:old.TESTING_STATUS,0) != nvl(:new.TESTING_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'TESTING_STATUS','NUMBER',:old.TESTING_STATUS,:new.TESTING_STATUS);
    end if;
    --
    --
    if nvl(:old.SECURITY_IMPACT,'1') != nvl(:new.SECURITY_IMPACT,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'SECURITY_IMPACT','VARCHAR2',:old.SECURITY_IMPACT,:new.SECURITY_IMPACT);
    end if;
    if nvl(:old.SECURITY_ASSIGNEE,'1') != nvl(:new.SECURITY_ASSIGNEE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'SECURITY_ASSIGNEE','VARCHAR2',:old.SECURITY_ASSIGNEE,:new.SECURITY_ASSIGNEE);
    end if;
    if nvl(:old.SECURITY_STATUS,0) != nvl(:new.SECURITY_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'SECURITY_STATUS','NUMBER',:old.SECURITY_STATUS,:new.SECURITY_STATUS);
    end if;
    --
    --
    if nvl(:old.ACCESSIBILITY_IMPACT,'1') != nvl(:new.ACCESSIBILITY_IMPACT,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'ACCESSIBILITY_IMPACT','VARCHAR2',:old.ACCESSIBILITY_IMPACT,:new.ACCESSIBILITY_IMPACT);
    end if;
    if nvl(:old.ACCESSIBILITY_ASSIGNEE,'1') != nvl(:new.ACCESSIBILITY_ASSIGNEE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'ACCESSIBILITY_ASSIGNEE','VARCHAR2',:old.ACCESSIBILITY_ASSIGNEE,:new.ACCESSIBILITY_ASSIGNEE);
    end if;
    if nvl(:old.ACCESSIBILITY_STATUS,0) != nvl(:new.ACCESSIBILITY_STATUS,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'ACCESSIBILITY_STATUS','NUMBER',:old.ACCESSIBILITY_STATUS,:new.ACCESSIBILITY_STATUS);
    end if;
    --
    --
    if nvl(:old.FOCUS_AREA,'1') != nvl(:new.FOCUS_AREA,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FOCUS_AREA','VARCHAR2',:old.FOCUS_AREA,:new.FOCUS_AREA);
    end if;
    if nvl(:old.RELEASE,'1') != nvl(:new.RELEASE,'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'RELEASE','VARCHAR2',:old.RELEASE,:new.RELEASE);
    end if;

    if nvl(to_char(:old.FEATURE_PRIORITY),'1') != nvl(to_char(:new.FEATURE_PRIORITY),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_PRIORITY','VARCHAR2',to_char(:old.FEATURE_PRIORITY),to_char(:new.FEATURE_PRIORITY));
    end if;
    if nvl(to_char(:old.FEATURE_STATUS),0) != nvl(to_char(:new.FEATURE_STATUS),0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_STATUS','NUMBER',:old.FEATURE_STATUS,:new.FEATURE_STATUS);
    end if;
    if nvl(to_char(:old.FEATURE_DESIRABILITY),'1') != nvl(to_char(:new.FEATURE_DESIRABILITY),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'FEATURE_DESIRABILITY','VARCHAR2',to_char(:old.FEATURE_DESIRABILITY),to_char(:new.FEATURE_DESIRABILITY));
    end if;
    if nvl(to_char(:old.APPLICATION_ID),'1') != nvl(to_char(:new.APPLICATION_ID),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'APPLICATION_ID','VARCHAR2',to_char(:old.APPLICATION_ID),to_char(:new.APPLICATION_ID));
    end if;
    if nvl(to_char(:old.PARENT_FEATURE_ID),'1') != nvl(to_char(:new.PARENT_FEATURE_ID),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'PARENT_FEATURE_ID','VARCHAR2',to_char(:old.PARENT_FEATURE_ID),to_char(:new.PARENT_FEATURE_ID));
    end if;
    if nvl(to_char(:old.DUE_DATE,'YYYYMMDD'),'1') != nvl(to_char(:new.DUE_DATE,'YYYYMMDD'),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'DUE_DATE','VARCHAR2',to_char(:old.DUE_DATE,'YYYYMMDD'),to_char(:new.DUE_DATE,'YYYYMMDD'));
    end if;
    if nvl(to_char(:old.START_DATE,'YYYYMMDD'),'1') != nvl(to_char(:new.START_DATE,'YYYYMMDD'),'1') then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'START_DATE','VARCHAR2',to_char(:old.START_DATE,'YYYYMMDD'),to_char(:new.START_DATE,'YYYYMMDD'));
    end if;

    if nvl(:old.event_id,0) != nvl(:new.event_id,0) then
       insert into wwv_flow_feature_history
            (feature_id, COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_VARCHAR2,NEW_VALUE_VARCHAR2)
            values
            (:new.id, 'EVENT_ID','NUMBER',:old.event_id,:new.event_id);
    end if;

    /*
    if dbms_lob.get_length(:old.FEATURE_DESC) != dbms_lob.get_length(:new.FEATURE_DESC) then
       insert into wwv_flow_feature_history
            (COLUMN_NAME,COLUMN_DATA_TYPE,OLD_VALUE_CLOB,NEW_VALUE_CLOB)
            values
            ('FEATURE_DESC','CLOB',:old.FEATURE_DESC,:new.FEATURE_DESC);
    end if;
    */

    end if;

    --
    -- TAG
    --
    wwv_flow_team.wwv_flow_team_tag_sync (
           p_component_type    => 'FEATURE',
           p_component_id      => :new.id,
           p_new_tags          => rtrim(trim(:new.FEATURE_TAGS),','),
           p_security_group_id => :new.security_group_id);

    -- set feature id
    if :new.feature_id is null and (inserting or updating) then
        select nvl(max(feature_id),0) + 1 into :new.feature_id
        from wwv_flow_features
        where security_group_id = nvl(wwv_flow_security.g_security_group_id,0);
    end if;

end wwv_flow_features_t1;
/

