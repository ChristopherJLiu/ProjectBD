CREATE VIEW WWV_FLOW_SEARCH_RESULT AS
  select n001    as flow_id,
       c001    as path,
       c002    as order_value,
       c003    as attribute_name,
       clob001 as attribute_value,
       c004    as link_url
  from wwv_flow_collections
 where collection_name = 'FLOW_SEARCH_RESULT'
/

