CREATE VIEW WWV_FLOW_BUG_STATUS_CODES AS
  select 10 id, wwv_flow_lang.system_message('ENTERED') the_name from dual union all
select 20 id, wwv_flow_lang.system_message('CONFIRMED') the_name from dual union all
select 30 id, wwv_flow_lang.system_message('ASSIGNED') the_name from dual union all
select 40 id, wwv_flow_lang.system_message('IN_PROGRESS') the_name from dual union all
select 80 id, wwv_flow_lang.system_message('FIXED_IN_DEVELOPMENT') the_name from dual union all
select 90 id, wwv_flow_lang.system_message('CONFIRMED_BY_QA') the_name from dual union all
select 100 id, wwv_flow_lang.system_message('COMPLETE') the_name from dual union all
select 200 id, wwv_flow_lang.system_message('DUPLICATE') the_name from dual union all
select 300 id, wwv_flow_lang.system_message('NOT_FEASIBLE_TO_FIX') the_name from dual union all
select 0 id, wwv_flow_lang.system_message('NOT_A_BUG') the_name from dual
/

