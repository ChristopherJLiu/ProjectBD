CREATE VIEW APEX_TEAM_BUGS AS
  select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    b.ID                          bug_id,
    b.BUG_ID                      friendly_bug_number,
    b.BUG_TITLE                   bug_title,
    b.ASSIGNED_TO                 assigned_to,
    b.BUG_SEVERITY                bug_severity,
    b.BUG_STATUS                  bug_status,
    b.PRIORITY                    priority,
    b.FIX_BY_RELEASE              fix_by_release,
    --
    b.ESTIMATED_FIX_DATE,
    b.ACTUAL_FIX_DATE,
    --
    b.BUG_DESCRIPTION,
    b.REPORTED_PLATFORM,
    b.REPORTED_BROWSER,
    b.REPORTED_OPERATING_SYSTEM,
    b.FEATURE_ID                  related_feature_id,
    b.TARGET_MILESTONE_ID         target_milestone_id,
    b.TASK_ID                     related_todo_id,
    b.DUPLICATE_OF_BUG,
    b.TAGS,
    --
    b.CUSTOMER_NAME               customer_name,
    b.CUSTOMER_ISSUE              customer_issue,
    --
    b.COMPONENT                   product_component,
    b.PRODUCT                     product_name,
    b.PRODUCT_VERSION             product_version,
    b.IMPACT                      impact_of_fix,
    b.APPLICATION_ID              application_id,
    b.PAGE_ID                     page_id,
    --
    b.CREATED_BY,
    b.CREATED_ON,
    b.UPDATED_BY,
    b.UPDATED_ON
from
    wwv_flow_bugs b,
    wwv_flow_companies w
where
    b.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

