CREATE TRIGGER WWV_FLOW_EFF_USERID_MAP_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_EFFECTIVE_USERID_MAP
  FOR EACH ROW
  begin
    if inserting then
        if :new.id is null then
            :new.id := wwv_flow_id.next_val;
        end if;
    end if;
    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

