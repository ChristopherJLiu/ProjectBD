CREATE TRIGGER WWV_FLOW_COMPANIES_T2
  BEFORE DELETE
  ON WWV_FLOW_COMPANIES
  FOR EACH ROW
  begin
    wwv_flow.g_workspace_delete_in_progress := true;
end;
/

