CREATE TRIGGER WWV_BIU_FLOW_BUILD_AUDIT_T
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_BUILDER_AUDIT_TRAIL
  FOR EACH ROW
  begin
    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

