CREATE TRIGGER WWV_FLOW_BUGS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_BUGS
  FOR EACH ROW
  begin
	  if :new.fix_by_release = '%'||'null%' then
	     :new.fix_by_release := null;
	  end if;
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.security_group_id is null then
        :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    if inserting and :new.created_by is null then
       :new.created_by := nvl(wwv_flow.g_user,USER);
    end if;
    if inserting and :new.created_on is null then
       :new.created_on := sysdate;
    end if;
    if inserting and :new.updated_by is null then
       :new.updated_by :=nvl(wwv_flow.g_user,user);
    end if;
    if inserting and :new.updated_on is null then
       :new.updated_on := sysdate;
    end if;
    if inserting or updating then
       :new.updated_by := nvl(wwv_flow.g_user,user);
       :new.updated_on := sysdate;
    end if;
    :new.assigned_to := trim(lower(:new.assigned_to));

    --
    -- TAG
    --
    wwv_flow_team.wwv_flow_team_tag_sync (
        p_component_type    => 'BUG',
        p_component_id      => :new.id,
        p_new_tags          => :new.TAGS,
        p_security_group_id => :new.security_group_id);

    --
    -- friendly id
    --
    if :new.bug_id is null and (inserting or updating) then
       select nvl(max(bug_id),0) + 1 into :new.bug_id from wwv_flow_bugs where security_group_id = nvl(wwv_flow_security.g_security_group_id,0);
    end if;

end wwv_flow_bugs_t1;
/

