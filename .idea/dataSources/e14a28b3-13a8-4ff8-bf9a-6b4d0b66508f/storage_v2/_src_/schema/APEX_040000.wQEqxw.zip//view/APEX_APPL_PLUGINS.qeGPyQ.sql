CREATE VIEW APEX_APPL_PLUGINS AS
  select p.id                        as plugin_id,
       f.workspace,
       f.application_id,
       f.application_name,
       case p.plugin_type
         when 'ITEM TYPE'          then 'Item Type'
         when 'DYNAMIC ACTION'     then 'Dynamic Action'
         when 'REGION TYPE'        then 'Region Type'
         when 'REPORT COLUMN TYPE' then 'Report Column Type'
         when 'VALIDATION TYPE'    then 'Validation Type'
         when 'PROCESS TYPE'       then 'Process Type'
         else                       p.plugin_type
       end                         as plugin_type,
       p.name,
       p.display_name,
       p.category,
       p.image_prefix              as file_prefix,
       p.plsql_code,
       p.render_function,
       p.ajax_function,
       p.validation_function,
       p.execution_function,
       p.builder_validation_function,
       p.migration_function,
       p.standard_attributes,
       p.sql_min_column_count,
       p.sql_max_column_count,
       p.sql_examples,
       p.attribute_01,
       p.attribute_02,
       p.attribute_03,
       p.attribute_04,
       p.attribute_05,
       p.attribute_06,
       p.attribute_07,
       p.attribute_08,
       p.attribute_09,
       p.attribute_10,
       nvl2(p.reference_id, 'Yes', 'No') as is_subscribed,
       ( select s.flow_id||'. '||s.display_name
           from wwv_flow_plugins s
          where s.id = p.reference_id )  as subscribed_from,
       p.reference_id                    as subscribed_from_id,
       p.help_text,
       p.version_identifier,
       p.about_url,
       p.plugin_comment                  as component_comment,
       p.created_by,
       p.created_on,
       p.last_updated_by,
       p.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p
 where p.flow_id = f.application_id
/

