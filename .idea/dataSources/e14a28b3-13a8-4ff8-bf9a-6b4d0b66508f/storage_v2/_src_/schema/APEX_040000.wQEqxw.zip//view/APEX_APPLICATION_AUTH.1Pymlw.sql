CREATE VIEW APEX_APPLICATION_AUTH AS
  select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    decode(a.REFERENCE_ID,
      null,'No','Yes')               is_subscribed,
    a.NAME                           authentication_scheme_name,
    a.DESCRIPTION                    ,
    a.PAGE_SENTRY_FUNCTION           page_sentry_function,
    a.SESS_VERIFY_FUNCTION           session_verify_function,
    a.INVALID_SESSION_PAGE           invalid_session_page,
    a.INVALID_SESSION_URL            invalid_session_url,
    --
    a.PRE_AUTH_PROCESS               pre_authentication_process,
    a.AUTH_FUNCTION                  authentication_function,
    a.POST_AUTH_PROCESS              post_authentication_process,
    --
    a.COOKIE_NAME                    cookie_name,
    a.COOKIE_PATH                    cookie_path,
    a.COOKIE_DOMAIN                  cookie_domain,
    decode(a.USE_SECURE_COOKIE_YN,'Y','Yes','N','No','No') cookie_secure,
    --
    a.LDAP_HOST                      ldap_host,
    a.LDAP_PORT                      ldap_port,
    a.LDAP_STRING                    ldap_dn_string,
    --
    a.ATTRIBUTE_01                   ldap_username_edit_function,
    a.ATTRIBUTE_02                   logout_url,
    a.ATTRIBUTE_03                   help_text,
    --a.ATTRIBUTE_04                   ,
    --a.ATTRIBUTE_05                   ,
    --a.ATTRIBUTE_06                   ,
    --a.ATTRIBUTE_07                   ,
    --a.ATTRIBUTE_08                   ,
    --
    --(select PATCH_NAME
    -- from   wwv_flow_patches
    -- where  id =a.REQUIRED_PATCH)    build_option,
    --
    a.LAST_UPDATED_BY                ,
    a.LAST_UPDATED_ON                ,
    a.id                             authentication_scheme_id,
    a.reference_id                   referenced_schema_id,
    --
    a.NAME
    ||' '||decode(a.REFERENCE_ID,null,'No','Yes')
    ||dbms_lob.substr(a.PAGE_SENTRY_FUNCTION,20,1)||dbms_lob.getlength(a.PAGE_SENTRY_FUNCTION)||'.'
    ||dbms_lob.substr(a.SESS_VERIFY_FUNCTION,20,1)||dbms_lob.getlength(a.SESS_VERIFY_FUNCTION)||'.'
    ||substr(a.INVALID_SESSION_PAGE,1,20)||length(a.INVALID_SESSION_PAGE)||'.'
    ||substr(a.INVALID_SESSION_URL ,1,20)||length(a.INVALID_SESSION_URL )||'.'
    ||dbms_lob.substr(a.PRE_AUTH_PROCESS,20,1)||dbms_lob.getlength(a.PRE_AUTH_PROCESS    )||'.'
    ||dbms_lob.substr(a.AUTH_FUNCTION   ,20,1)||dbms_lob.getlength(a.AUTH_FUNCTION       )||'.'
    ||dbms_lob.substr(a.POST_AUTH_PROCESS,20,1)||dbms_lob.getlength(a.POST_AUTH_PROCESS   )||'.'
    ||substr(a.COOKIE_NAME         ,1,20)||length(a.COOKIE_NAME         )||'.'
    ||substr(a.COOKIE_PATH         ,1,20)||length(a.COOKIE_PATH         )||'.'
    ||substr(a.COOKIE_DOMAIN       ,1,20)||length(a.COOKIE_DOMAIN       )||'.'
    ||substr(a.USE_SECURE_COOKIE_YN,1,1)||length(a.USE_SECURE_COOKIE_YN)||'.'
    ||substr(a.LDAP_HOST           ,1,20)||length(a.LDAP_HOST           )||'.'
    ||substr(a.LDAP_PORT           ,1,20)||length(a.LDAP_PORT           )||'.'
    ||substr(a.LDAP_STRING         ,1,20)||length(a.LDAP_STRING         )||'.'
    ||substr(a.ATTRIBUTE_01        ,1,20)||length(a.ATTRIBUTE_01        )||'.'
    ||substr(a.ATTRIBUTE_02        ,1,20)||length(a.ATTRIBUTE_02        )||'.'
    ||substr(a.ATTRIBUTE_03        ,1,20)||length(a.ATTRIBUTE_03        )
    component_signature
from wwv_flow_custom_auth_setups a,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = a.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

