CREATE TRIGGER WWV_FLOW_LOCK_PAGE_T2
  BEFORE DELETE
  ON WWV_FLOW_LOCK_PAGE
  FOR EACH ROW
  begin
insert into wwv_flow_lock_page_log (
   lock_id,lock_flow,lock_page,ACTION,ACTION_DATE,DEVELOPER,lock_comment)
   values (
   :old.id, :old.flow_id, :old.object_id,'UNLOCK',sysdate,v('USER'),:old.lock_comment);
end;
/

