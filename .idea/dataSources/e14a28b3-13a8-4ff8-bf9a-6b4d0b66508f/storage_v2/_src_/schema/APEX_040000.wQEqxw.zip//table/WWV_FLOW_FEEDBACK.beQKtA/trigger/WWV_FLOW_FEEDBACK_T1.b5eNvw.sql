CREATE TRIGGER WWV_FLOW_FEEDBACK_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_FEEDBACK
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.security_group_id is null then
        if nvl(:new.APPLICATION_ID,0) >= 4000 and nvl(:new.application_id,0) <= 4999 then
           :new.security_group_id := 10;
        else
           :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
        end if;
    end if;

    if :new.logging_security_group_id is null then
       :new.logging_security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
    if :new.logged_by_workspace_name is null then
       for c1 in (select short_name from WWV_FLOW_COMPANIES where PROVISIONING_COMPANY_ID = :new.logging_security_group_id) loop
           :new.logged_by_workspace_name := c1.short_name;
       end loop;
    end if;

    if inserting and not wwv_flow.g_import_in_progress then
       :new.created_by := coalesce(:new.created_by, wwv_flow.g_user, user);
       :new.created_on := coalesce(:new.created_on, current_timestamp);
       :new.updated_by := coalesce(:new.updated_by, wwv_flow.g_user, user);
       :new.updated_on := coalesce(:new.updated_on, current_timestamp);
    elsif updating and not wwv_flow.g_import_in_progress then
       :new.updated_by := coalesce(wwv_flow.g_user, user);
       :new.updated_on := current_timestamp;
    end if;

    -- set feedback ID
	if :new.feedback_id is null and inserting and :new.application_id is not null then
	    select nvl(max(feedback_id),0) + 1 into :new.feedback_id
	    from wwv_flow_feedback
	    where security_group_id = (select security_group_id from wwv_flows where id = :new.application_id);
	end if;
	--
	-- TAG
	--
	wwv_flow_utilities.wwv_flow_team_tag_sync (
	       p_component_type    => 'FEEDBACK',
	       p_component_id      => :new.id,
	       p_new_tags          => rtrim(trim(:new.TAGS),','),
	       p_security_group_id => :new.security_group_id);

end wwv_flow_feedback_t1;
/

