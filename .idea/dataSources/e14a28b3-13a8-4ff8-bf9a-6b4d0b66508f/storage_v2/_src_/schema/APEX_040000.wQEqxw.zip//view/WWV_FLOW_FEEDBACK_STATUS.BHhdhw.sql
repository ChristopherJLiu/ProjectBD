CREATE VIEW WWV_FLOW_FEEDBACK_STATUS AS
  select 0 id, wwv_flow_lang.system_message('NO_STATUS') the_name from dual union all
select 1 id, wwv_flow_lang.system_message('ACKNOWLEDGED') the_name from dual union all
select 2 id, wwv_flow_lang.system_message('ADDITIONAL_INFORMATION_REQUESTED') the_name from dual union all
select 3 id, wwv_flow_lang.system_message('OPEN_PROCESSING_FEEDBACK') the_name from dual union all
select 4 id, wwv_flow_lang.system_message('CLOSED') the_name from dual
/

