CREATE TRIGGER WWV_BIU_FLOW_PLUGIN_AUDIT
  BEFORE INSERT OR UPDATE OR DELETE
  ON WWV_FLOW_PLUGINS
  FOR EACH ROW
  declare
    l_action varchar2(1);
begin
    l_action := case
                  when inserting then 'I'
                  when updating  then 'U'
                  else                'D'
                end;
    begin
        wwv_flow_audit.audit_action (
           p_table_name  => 'WWV_FLOW_PLUGINS',
           p_action      => l_action,
           p_table_pk    => nvl(:old.id, :new.id),
           p_object_name => nvl(:new.name,:old.name) );
    exception when others then null;
    end;
end;
/

