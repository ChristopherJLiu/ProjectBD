CREATE VIEW APEX_MIGRATION_ACC_PROJECTS AS
  select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
        d.description                                   description,
     --
        d.migration_type                                migration_type,
     --
        d.created_by                                    project_owner,
     --
        a.dbpathname                                    accdb_pathname,
     --
       (select count(*) from wwv_mig_acc_tables
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              tables,
     --
       (select count(*) from wwv_mig_acc_queries
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              queries,
     --
       (select count(*) from wwv_mig_acc_forms
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              forms,
     --
       (select count(*) from wwv_mig_acc_reports
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              reports,
     --
       (select count(*) from wwv_mig_acc_pages
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              pages,
     --
       (select count(*) from wwv_mig_acc_modules
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              modules,
     --
       (select count(*) from wwv_mig_acc_relations
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              relations,
     --
        a.jetversion                                    jetversion,
     --
        a.accessversion                                 accessversion,
     --
        a.dbname                                        dbname,
     --
        a.dbid                                          dbid,
     --
        a.dbsize                                        dbsize,
     --
        a.isappdb                                       isappdb,
     --
        a.isattacheddb                                  isattacheddb,
     --
        a.startupform                                   startupform,
     --
        a.linkdbid                                      linkdbid,
     --
        a.created_by                                    created_by,
     --
        d.last_updated_on                               last_modified_on,
     --
        d.last_updated_by                               last_modified_by,
     --
        s.schema                                        schema,
     --
        w.short_name                                    workspace,
     --
        w.provisioning_company_id                       workspace_id
from
        wwv_mig_access a,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
where
        (s.schema = user or user in ('SYS','SYSTEM','APEX_040000') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.PROVISIONING_COMPANY_ID, a.project_id
/

